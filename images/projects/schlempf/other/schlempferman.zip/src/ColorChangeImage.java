
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.awt.* ;
import java.awt.image.* ;

/** Cr�e un filtre de couleur:
* Permet de n'utiliser qu'une seule image pour tous les joueurs, en
* appliquant un filtre de couleur sur chaque image pour avoir des persos
* de couleurs diff�rentes
*/

public class ColorChangeImage extends RGBImageFilter {
    // Couleur qui sera remplac�e dans l'image
    private Color aRemplacer;
    
    // Nouvelle couleur de l'image
    private Color remplacement;

    /**
    * Class Constructor
    * @param nouv Nouvelle couleur de l'image
    * @param rempl Couleur qui sera remplac�e
    */

    ColorChangeImage(Color nouv, Color rempl)  {
        canFilterIndexColorModel = true;
        aRemplacer = nouv;
        remplacement = rempl;
    }

    /**
    * Cr�e un filtre RGB en fonction de la couleur
    * m�thode surcharg�e de la classe RGBImageFilter
    */

    public int filterRGB(int x, int y, int rgb) {
        // Retourne l'entier correspondant � la couleur
        if (rgb == aRemplacer.getRGB())  {
            return remplacement.getRGB();
        }
        return rgb;
    }    
}
