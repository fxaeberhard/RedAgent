
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


/**
* G�re les variables de la partie
*/

public class Partie implements Constantes {
    // Lien vers le plateau
    public static Plateau plateau;
    // un joueur est mort
    boolean unEstMort;
    // Le num�ro du niveau en cours
    int numNiveau;
    // Le num�ro de notre joueur
    int numJoueur;
    // Le nombre de parties d�j� effectu�es
    int nbParties;
    // Les persos de la partie
    Perso[] tabPerso;
    // Une boite de dialogue
    BoiteDialogue message;

    /**
    * Class Constructor
    * Initialise les scores pour la partie en cours
    * - tabPerso   : le tableau des joueurs
    */

    public Partie(Perso[] tabPerso, int numJoueur) {
        this.tabPerso = tabPerso;
        this.numJoueur = numJoueur;
        unEstMort = false;
        numNiveau = 1;
        nbParties = 3;
    }

    /**
    * Initialise un pointeur sur le plateau
    * @param p plateau
    */

    public static void initPlateau(Plateau p) {
        plateau = p;
    }

    /**
    * Dit si la partie est termin�e
    */

    boolean finPartie() {
        // Partie termin�e quand un joueur est mort
        return (unEstMort);
    }

    /**
    * Affiche la fenetre avec les scores
    */

    void afficherVainqueur() {
        if ((tabPerso[0].nbVictoires < NBCOUPES) && (tabPerso[1].nbVictoires < NBCOUPES)) {
            if (numJoueur == 0)
                if (plateau.typeJoueur == 1)
                    message = new BoiteDialogue("Score : " + tabPerso[0].nbVictoires + " � " + tabPerso[1].nbVictoires);
                else
                    System.out.println("Score : " + tabPerso[0].nbVictoires + " � " + tabPerso[1].nbVictoires);
            else
                if (plateau.typeJoueur == 1)
                    message = new BoiteDialogue("Score : " + tabPerso[1].nbVictoires + " � " + tabPerso[0].nbVictoires);
                else
                    System.out.println("Score : " + tabPerso[1].nbVictoires + " � " + tabPerso[0].nbVictoires);
        }
    }
}
