
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


/**
* Repr�sente un joueur au niveau jeu
*/

public class Joueur {
    // Nom du joueur
    String nom;
    // Le numero du joueur 
    int numero;
    // A gagn� la partie
    boolean gagnant;
    // Le nombre de victoires
    int nbVictoires; 
    // Le nombre de bombes  
    int nbBombe;
    // La puissance des bombes  
    int puissance;
    // Dit si le joueur est vivant 
    boolean vivant;
    // Malus de lenteur  
    boolean lenteur;
    // La vitesse du joueur
    int vitesse;
    // Indique si le joueur pose une bombe 
    boolean pose;
    
    /**
    * Class Constructor
    * @param n Le nom du Joueur
    * @param num  Le num�ro du Joueur
    */
    
    public Joueur(String n, int num) {
        nom = n;
        numero = num;
        
        gagnant = false;
        nbVictoires = 0;
        
        nbBombe = 1;
        puissance = 1;
        
        vivant = true;
        lenteur = false;
        
        vitesse = 2;
        pose = false;
    }
    
    /**
    * Retourne l'etat du joueur: vivant ou mort
    */
   
    boolean estVivant() {
        return vivant;
    }
    
    /**
    * R�initialise l'�tat du joueur pour la nouvelle partie
    */
   
    void reinitJoueur() {
        nbBombe = 1;
        puissance = 1;
        vivant = true;
        lenteur = false;
        vitesse = 2;
        pose = false;
    }
    
    /**
    * Dit si le joueur a gagn� la partie
    */
   
    boolean estGagnant() {
        return gagnant;
    }
}
