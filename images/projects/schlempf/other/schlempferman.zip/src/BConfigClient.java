/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 * Modified by  Fran�ois-Xavier Aeberhard & Mikael Pelle
 */

import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.help.*;

/**
 * Fen�tre permettant de r�gler les param�tres de connexion
 */

public class BConfigClient
    extends JFrame
    implements ActionListener {
  BClient bclient;

  /* MIKE Barre de menu */
  JMenuBar jmb = new JMenuBar();

  JMenu config = new JMenu("Commandes");
  JMenuItem quitter = new JMenuItem("Quitter");
  JMenuItem connecter = new JMenuItem("Se connecter au serveur");
  JMenuItem lancer = new JMenuItem("Lancer la partie");

  JMenu help = new JMenu("Aide");
  JMenuItem javahelp = new JMenuItem("JavaHelp");

  JMenu about = new JMenu("?");
  JMenuItem apropos = new JMenuItem("A propos");
  JMenuItem aufait = new JMenuItem("Au fait...");
  JMenuItem gnugpl = new JMenuItem("GNU-GPL");

  JInternalFrame jif1 = new JInternalFrame("Param�tres connexion");
  JInternalFrame jif2 = new JInternalFrame("Informations connexion");

  JPanel jp1 = new JPanel();
  JPanel jp2 = new JPanel();
  JPanel jp3 = new JPanel();
  JPanel jp4 = new JPanel();
  JPanel jp5 = new JPanel();

  JTextArea info = new JTextArea();
  JScrollPane areaScrollPane = new JScrollPane(info);

  JTextField port = new JTextField("10000", 15);
  JTextField nom = new JTextField("Bombmaster", 15);
  JTextField serveur = new JTextField("localhost", 15);
  ButtonGroup bg = new ButtonGroup();
  JRadioButton humain = new JRadioButton("Humain", true);
  JRadioButton ordinateur = new JRadioButton("Ordinateur");

  int prt = 0;
  String serv, nomJoueur;

  double noteEntree = 0;

  /** Constructor with the ability to config the client through command line arguments **/
  BConfigClient(BClient bclient1, String typ, String server, String port,
                String nom) {
    this(bclient1);

    if (typ.equals("humain")) {
      this.humain.setSelected(true);
    }
    else {
      this.ordinateur.setSelected(true);
    }
    this.serveur.setText(server);
    this.port.setText(port);
    this.nom.setText(nom);

  }

  /**
   * Class Constructor
   */

  BConfigClient(BClient bcl) {
    super("Client - Schlempferman Java 2004");

    bclient = bcl;

    this.getContentPane().setLayout(new GridLayout(2, 1));
    jif1.getContentPane().setLayout(new GridLayout(4, 1));
    this.activerLance(false);

    config.setMnemonic(KeyEvent.VK_C);
    config.add(connecter);
    connecter.setMnemonic(KeyEvent.VK_S);
    config.add(lancer);
    lancer.setMnemonic(KeyEvent.VK_L);
    config.add(quitter);
    quitter.setMnemonic(KeyEvent.VK_Q);

    connecter.addActionListener(this);
    lancer.addActionListener(this);
    quitter.addActionListener(this);

    /* MIKE Ajout des menus � la barre de menu */
    help.setMnemonic(KeyEvent.VK_A);
    help.add(javahelp);
    javahelp.setMnemonic(KeyEvent.VK_H);
    about.add(apropos);
    apropos.setMnemonic(KeyEvent.VK_A);
    about.add(aufait);
    aufait.setMnemonic(KeyEvent.VK_U);
    about.add(gnugpl);
    gnugpl.setMnemonic(KeyEvent.VK_G);

    javahelp.addActionListener(this);
    apropos.addActionListener(this);
    aufait.addActionListener(this);
    gnugpl.addActionListener(this);

    jmb.add(config);
    jmb.add(help);
    jmb.add(about);

    this.setSize(500, 360);
    this.setJMenuBar(jmb);
    centrer();
    this.setVisible(true);
    this.setResizable(false);

    jif1.setSize(150, 150);

    jp1.setLayout(new BorderLayout());
    jp2.setLayout(new BorderLayout());
    jp3.setLayout(new BorderLayout());
    jp4.setLayout(new BorderLayout());
    jp5.setLayout(new BorderLayout());

    jp1.add(new Label("Nom du bomberman : "), BorderLayout.WEST);
    jp1.add(nom, BorderLayout.EAST);
    jp2.add(new Label("Serveur :          "), BorderLayout.WEST);
    jp2.add(serveur, BorderLayout.EAST);
    jp3.add(new Label("Port :             "), BorderLayout.WEST);
    jp3.add(port, BorderLayout.EAST);

    bg.add(humain);
    bg.add(ordinateur);
    jp5.add(humain, BorderLayout.WEST);
    jp5.add(ordinateur, BorderLayout.EAST);
    jp4.add(new Label("Type de joueur :   "), BorderLayout.WEST);
    jp4.add(jp5, BorderLayout.EAST);

    jif1.setVisible(true);

    jif1.getContentPane().add(jp1);
    jif1.getContentPane().add(jp2);
    jif1.getContentPane().add(jp3);
    jif1.getContentPane().add(jp4);
    jif1.getContentPane().doLayout();

    info.setEditable(false);
    info.setFont(new Font("newf", Font.ITALIC, 11));
    areaScrollPane.setVerticalScrollBarPolicy(JScrollPane.
                                              VERTICAL_SCROLLBAR_ALWAYS);

    jif2.getContentPane().add(areaScrollPane);

    this.getContentPane().add(jif2);
    jif2.setVisible(true);

    this.getContentPane().add(jif1);

    this.addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        bclient.annuler();
      }
    });
  }

  /**
   * JavaHelp
   */

  private HelpBroker hb = null;
  private HelpSet hs = null;
  final String HELPSETFILE = "javahelp/myhelpset.hs";

  private boolean prepareHelp(String helpset) {
    URL hsURL = null;

    try {
      hsURL = new URL( (new File(".")).toURL(), helpset);
      hs = new HelpSet(null, hsURL);
    }
    catch (Exception ee) {
      return false;
    }
    try {
      hb = hs.createHelpBroker("bomberman");
    }
    catch (Exception ee) {
      return false;
    }
    return true;
  }

  private void showJHelp() {
    if (prepareHelp(HELPSETFILE)) {
      hb.setDisplayed(true);
    }
  }

  /**
   * G�re les clics sur les boutons
   */

  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == connecter) {
      nomJoueur = new String(nom.getText());
      serv = new String(serveur.getText());

      try {
        prt = Integer.decode(port.getText()).intValue();
      }
      catch (Exception ex) {
        System.out.println(ex);
      }

      info.append(nomJoueur + " : Tentative de connexion � " + serv +
                  " sur le port " + prt + "...\n");

      bclient.lance();
    }

    if (e.getSource() == lancer) {
      try {
        // Avertit le serveur que la partie commence
        bclient.out.writeUTF("go");
        bclient.lancerJeu();
      }
      catch (Exception ex) {
        System.out.println(ex);
      }
    }

    if (e.getSource() == quitter) {
      this.removeNotify();
      bclient.annuler();
    }
    if (e.getSource() == javahelp) {
      showJHelp();
    }

    if (e.getSource() == apropos) {
      if (noteEntree > 0) {

        About apropos = new About
            ("Vous esp�rez avoir une note de " + noteEntree +
             " au projet de Programmation II.");

      }
      else {
        About apropos = new About
            (
            "Schlempferman Java 2004 (v1.0) - (c) Francois-Xavier Aeberhard & Mikael Pelle");
      }
    }

    if (e.getSource() == aufait) {
      AuFait apropos = new AuFait("Au fait...", noteEntree, this);
    }
    if (e.getSource() == gnugpl) {
      GPL gnugpl = new GPL();
    }
  }

  /**
   * Ajoute un message a la TextArea
   */

  void ecrire(String message) {
    Point p;

    info.append(message);

    // D�lai systeme pour rafraichissement
    try {
      Thread.sleep(50);
    }
    catch (Exception ex) {
      System.out.println(ex);
    }

    p = new Point(0,
                  (int) (info.getSize().getHeight() -
                         areaScrollPane.getViewport().getExtentSize().getHeight()));
    areaScrollPane.getViewport().setViewPosition(p);
  }

  /**
   * Active ou desactive l'entr�e menu pour la connexion
   */

  void activerConnecte(boolean b) {
    connecter.setEnabled(b);
  }

  /**
   * Active ou desactive l'entr�e menu pour le lancement de la partie
   */

  void activerLance(boolean b) {
    lancer.setEnabled(b);
  }

  /**
   * Donne le port de connexion au serveur
   */

  int port() {
    return prt;
  }

  /**
   * Donne le nom du serveur
   */

  String serveur() {
    return serv;
  }

  /**
   * Donne le nom du joueur
   */

  String nom() {
    return nomJoueur;
  }

  /**
   * Donne le type du client : 1 = humain, 2 = ordinateur
   */

  int typeClient() {
    int t;
    if (humain.isSelected()) {
      t = 1;
    }
    else if (ordinateur.isSelected()) {
      t = 2;
    }
    else {
      t = 0;
    }
    return t;
  }

  /**
   * Centre la fen�tre dans l'�cran
   */

  void centrer() {
    Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
    int largeurEcran = tailleEcran.width;
    int hauteurEcran = tailleEcran.height;
    int largeur = getSize().width;
    int hauteur = getSize().height;
    int xPos = (largeurEcran - largeur) / 2;
    int yPos = (hauteurEcran - hauteur) / 2;
    setLocation(xPos, yPos);
  }

}
