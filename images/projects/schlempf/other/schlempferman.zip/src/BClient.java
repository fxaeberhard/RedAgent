/**
 * <p>Titre : Schlempferman Java 2004 </p>
 * <p>Description : Java Game </p>
 * <p>Copyright : 2004 </p>
 * <p>Soci�t� : EPFL SIN </p>
 * @author Fran�ois-Xavier Aeberhard & Mikael Pelle
 * @version 1.0
 */


import javax.swing.*;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.net.Socket;
import java.util.Hashtable;
import java.util.Dictionary;
import java.util.Random;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;



/**
* Le client permettant de se connecter au serveur
*/

public class BClient implements Runnable, Constantes {
    // IHM pour le contr�le du serveur
    public BConfigClient bcc;

    // Pointeur sur le plateau de jeu
    Plateau plateau;

    // Socket de connexion au serveur
    Socket sock;
    // Flux de donn�es en entr�e
    DataInputStream in;
    // Flux de donn�es en sortie
    DataOutputStream out;

    // Objet sur lesquel on synchronise
    Object synchro = new Object();

    // Nom du joueur
    String nom;
    // Num�ro du joueur
    int numero;
    // Type du client : 1 = humain, 2 = ordinateur
    int typeClient;

    // Port de connexion au serveur
    int port;
    // Nom du serveur auquel le client est connect�
    String serveur;

    // Donn�es recues du serveur
    String serveurParole;

    /**
    * Constructeur de BClient
    * @param b Pointeur sur la fen�tre principale
    */

    BClient() {
        bcc = new  BConfigClient(this);
    }



    /** Constructor with the ability to configure the client thorough command line arguments **/
    BClient(String typ, String server, String port, String nom, String launch) {
	synchro = new Object();
	bcc = new BConfigClient(this, typ, server, port, nom);

	//forge the connect event on bcc (we can do this since we have no package structure and can thus access
	//protected members
	ActionEvent connectAction = new ActionEvent(bcc.connecter, 0, "");
	bcc.actionPerformed(connectAction);

	//we give the system 2 seconds time to connect before launching
	if (launch.equals("true")) {
	    Timer timer = new Timer(2000, new ActionListener() {
		    public void actionPerformed(ActionEvent evt) {
			callLaunch();
		    }
		});
	    timer.setRepeats(false);
	    timer.start();
	}
    }

    /** This method initialized the launch **/
    private void callLaunch() {
	ActionEvent launchAction = new ActionEvent(bcc.lancer, 0, "");
	bcc.actionPerformed(launchAction);
    }

    /**
    * Thread client, �coute du serveur, et traitement des donn�es re�ues
    */

    public void run() {
        serveur = bcc.serveur();
        port = bcc.port();
        nom = bcc.nom();
        typeClient = bcc.typeClient();

        try {
            synchronized(synchro) {
                sock = new Socket(serveur, port);

                in = new DataInputStream(sock.getInputStream());
                out = new DataOutputStream(sock.getOutputStream());

                bcc.activerConnecte(false);
                bcc.ecrire(nom + " : Vous �tes connect�!\n");
                bcc.ecrire(nom + " : Initialisation de la partie en cours...Patientez\n");

                if(sock != null) {
                    out.writeUTF(nom);
                }
            }

            if(sock != null) serveurParole = in.readUTF();
            while(sock != null) {

                if(serveurParole.startsWith("NUM")) {
                    String s = serveurParole.substring(3);
                    numero = Integer.decode(s).intValue();
                }

                if(serveurParole.compareTo("initOK") == 0) {
                    bcc.ecrire("Les deux joueurs sont pr�sents\n");
                    bcc.ecrire("Vous pouvez d�marrer la partie maintenant\n");
                    bcc.activerLance(true);
                }

                if(serveurParole.compareTo("go") == 0) {
                    lancerJeu();
                }

                if(serveurParole.startsWith("stop")) {
                    bcc.ecrire(nom + ": Vous avez �t� d�connect�\n");
                    bcc.ecrire(serveurParole.substring(4) + " a quitt� la partie\n");
                    break;
                }

                if(serveurParole.compareTo("shutdown") == 0) {
                    bcc.ecrire(nom + ": Vous avez �t� d�connect�\n");
                    bcc.ecrire("Le serveur a mis fin � la session\n");
                    break;
                }

                if(serveurParole.startsWith("POSITION")) {
                    String s = serveurParole.substring(8, 9);
                    int num = Integer.decode(s).intValue();
                    s = serveurParole.substring(serveurParole.indexOf('-') + 1, serveurParole.lastIndexOf('-'));
                    int i = Integer.decode(s).intValue();
                    s = serveurParole.substring(serveurParole.lastIndexOf('-') + 1, serveurParole.length());
                    int j = Integer.decode(s).intValue();

                    plateau.tabPerso[num].repositionner(i, j);
                }

                if(serveurParole.startsWith("MORT")) {
                    String s = serveurParole.substring(4, 5);
                    int num = Integer.decode(s).intValue();
                    s = serveurParole.substring(serveurParole.lastIndexOf('-') + 1, serveurParole.length());
                    int n = Integer.decode(s).intValue();

                    plateau.tabPerso[n].explosePerso();
                }

                if(serveurParole.startsWith("POSE")) {
                    String s = serveurParole.substring(4, 5);
                    int num = Integer.decode(s).intValue();
                    s = serveurParole.substring(serveurParole.indexOf('-') + 1, serveurParole.lastIndexOf('-'));
                    int i = Integer.decode(s).intValue();
                    s = serveurParole.substring(serveurParole.lastIndexOf('-') + 1, serveurParole.length());
                    int j = Integer.decode(s).intValue();

                    plateau.tabPerso[num].poseBombe(i, j);
                }

                if (sock != null) serveurParole = in.readUTF();
            }

            bcc.activerConnecte(true);
            if(sock != null) {
                sock.close();
                sock = null;
            }
        }
        catch(Exception ex) {
            bcc.activerConnecte(true);
            bcc.ecrire("Impossible de se connecter au serveur\n");
            bcc.ecrire("V�rifiez les param�tres et retentez une connexion\n");
            sock = null;
        }
    }

    /**
    * Lance la partie
    */

    public void lancerJeu() {
        bcc.ecrire("C'est parti !\n");
        bcc.ecrire("Bonne chance " + nom + "...\n");
        bcc.setVisible(false);
        plateau = new Plateau(this);
        if (bcc.typeClient() == 1) {     // MIKE Lance la musique d'ambiance
          new Sound("snd/haiducii.mid"); // sur un seul client sinon tro moche en polyphonique ;-)
        }
      }
      /**
       * Ferme la connexion et quitte
       */

    public void annuler() {
        synchronized(synchro) {
            try {
                if (sock != null) {
                    out.writeUTF("shutdown");
                    sock.close();
                    sock = null;
                }
            }
            catch(Exception ex) {;}

            System.exit(1);
        }
    }

    /**
    * Lance le thread Client
    */

    void lance() {
        new Thread(this).start();
    }


    /**
     * main Method. If no Parameters are given, a configuration window is shown.
     * In all other cases the application is launched directly.
     *
     * Format: java BClient command1=argument1 command2=argument2 etc
     * Commands:
     * typ=[humain|ordinateur]	(default ordinateur)
     * server=xxx				(default localhost)
     * port=xxx					(default 10000)
     * nom=xxx					(default player + random number)
     * launch=[true|false]		(default false) defines whererver or not this client should launch the game
     */
    public static void main(String args[])
    {
	if (args.length == 0) {
	    BClient bclient = new BClient();
	} else {
	    //parse command line parameters
	    Dictionary dict = new Hashtable();
	    for (int i = 0; i < args.length; i++) {
		String argument = args [i].trim();
		if ((argument.indexOf('=') == -1) || (argument.endsWith("=")))
		    continue;
		String command = argument.substring(0, argument.indexOf('='));
		String value = argument.substring(argument.indexOf('=') + 1);
		dict.put(command, value);
	    }

	    String typ = loadFromDict(dict, "typ", "ordinateur");
	    String server = loadFromDict(dict, "server", "localhost");
	    String port = loadFromDict(dict, "port", "10000");
	    String nom = loadFromDict(dict, "nom", "player" + new Random().nextInt());
	    String launch = loadFromDict(dict, "launch", "false");

	    BClient bclient = new BClient(typ, server, port, nom, launch);
	}
    }

    /** Small help method **/
    private static String loadFromDict(Dictionary dict, String key, String def) {
	String value = (String) dict.get(key);
	if (value == null)
	    return def;
	return value;
    }

}
