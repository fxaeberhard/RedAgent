
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.awt.*;

/**
* Interface contenant toutes les contantes utilis�es dans le jeu
*/

public interface Constantes {
    /** OFFSET Taille d'un Block en pixels */
    final int OFFSET = 32;

    /** NBLIGNES Nombre de lignes d'un niveau */
    final int NBLIGNES = 13;
    
    /** NBCOLONNES Nombre de colonnes d'un niveau */
    final int NBCOLONNES = 19;

    /** LONGUEUR Longueur du Plateau en pixels */
    final int LONGUEUR = NBCOLONNES * OFFSET;
    
    /** LARGEUR Largeur du plateau en pixels */
    final int LARGEUR = NBLIGNES * OFFSET;

    /** HAUT Direction HAUT */
    final int HAUT = 0;
    /** BAS Direction BAS */
    final int BAS = 1;
    /** GAUCHE Direction GAUCHE */
    final int GAUCHE = 2;
    /** DROITE Direction DROITE */
    final int DROITE = 3;

    /** Puissance maximum des bombes */
    final int PUISSANCE_MAX = 8;

    /** NBCOUPES Nombre de victoires n�cessaires pour changer de niveau */
    final int NBCOUPES = 2;

    /** tab[] Les couleurs des persos */
    static Color tab[] = {Color.cyan, Color.yellow};
}
