
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import javax.swing.border.*;

/**
* Fen�tre permettant de r�gler les param�tres du serveur
*/

public class BConfigServeur extends JFrame implements ActionListener {
    BServeur bserv;

    JMenuBar jmb =                  new JMenuBar();
    JMenu config =                  new JMenu("Commandes");
    JMenuItem lancer =              new JMenuItem("Lancer le serveur");
    JMenuItem quitter =             new JMenuItem("Quitter");

    JInternalFrame jif1 =           new JInternalFrame("Configuration du serveur");
    JInternalFrame jif2 =           new JInternalFrame("Informations serveur");

    JPanel jp1 =                    new JPanel();

    JTextField port =               new JTextField ("10000", 5);
    JTextField nbPort =             new JTextField ("10", 5);
    JTextArea info =                new JTextArea();
    JScrollPane areaScrollPane =    new JScrollPane(info);

    int nb = 0, prt = 0, nbPrt = 0;


    /** Constructor with default values **/
    BConfigServeur(BServeur bserveur, String portstart, String portrange) {
	this(bserveur);

	port.setText(portstart);
	nbPort.setText(portrange);

	//the launch will be done from the constructor of BServeur since the reference for bcs must be set before launching
    }

    /**
    * Class Constructor
    */
    BConfigServeur(BServeur bs) {
        super("Serveur - Schlempferman Java 2004");

        bserv = bs;

        // Nombre de joueurs
        nb = 2;

        this.getContentPane().setLayout(new GridLayout(2, 1));
        jif1.getContentPane().setLayout(new GridLayout(1, 1));

        config.setMnemonic(KeyEvent.VK_C);
        config.add(lancer);
        lancer.setMnemonic(KeyEvent.VK_L);
        config.add(quitter);
        quitter.setMnemonic(KeyEvent.VK_Q);

        lancer.addActionListener(this);
        quitter.addActionListener(this);

        jmb.add(config);

        setSize(500, 360);
        setJMenuBar(jmb);
        centrer();
        setVisible(true);
        setResizable(false);

        jp1.setBorder(new TitledBorder("Choix des ports de communication"));
        jp1.add(new Label("Premier n� de port"));
        jp1.add(port);
        jp1.add(new Label("Nombre de ports"));
        jp1.add(nbPort);

        jif1.getContentPane().add(jp1);
        jif1.getContentPane().doLayout();

        areaScrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);
        jif2.getContentPane().add(areaScrollPane);
        jif2.setVisible(true);

        this.getContentPane().add(jif2);
        jif2.setVisible(true);
        this.getContentPane().add(jif1);
        jif1.setVisible(true);

        this.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                bserv.annuler();
            }
        }
        );
    }

    /**
    * G�re les clics sur les boutons
    */

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == lancer) {
            try {
                prt = Integer.decode(port.getText()).intValue();
                nbPrt = Integer.decode(nbPort.getText()).intValue();
            }
            catch(Exception ex) {
                System.out.println(ex);
            }

            info.setEditable(false);
            info.setFont(new Font("newf", Font.ITALIC, 11));
            ecrire("Tentative de lancement du serveur sur les ports " + prt + " � " + (prt + nbPrt - 1) + "...\n");

            bserv.lance();
        }
        else if (e.getSource() == quitter) {
            this.removeNotify();
            bserv.annuler();
        }
    }

    /**
    * Ajoute un message a la TextArea
    */

    void ecrire (String message) {
        Point p;

        info.append(message);

        // D�lai systeme pour rafraichissement
        try {
            Thread.sleep(50);
        }
        catch(Exception ex) {
            System.out.println(ex);
        }

        p = new Point(0, (int)(info.getSize().getHeight() - areaScrollPane.getViewport().getExtentSize().getHeight()));
        areaScrollPane.getViewport().setViewPosition(p);
    }

    /**
    * Donne le port de connexion au serveur
    */

    int port() {
        return prt;
    }

    /**
    * Donne le nombre de ports de connexion au serveur
    */

    int nbPort() {
        return nbPrt;
    }

    /**
    * Active ou desactive le menu de lancement du serveur
    */

    void activerLance(boolean b) {
        lancer.setEnabled(b);
    }

    /**
    * Centre la fen�tre dans l'�cran
    */

    void centrer() {
        Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
        int largeurEcran = tailleEcran.width;
        int hauteurEcran = tailleEcran.height;
        int largeur = getSize().width;
        int hauteur = getSize().height;
        int xPos = (largeurEcran - largeur) / 2;
        int yPos = (hauteurEcran - hauteur) / 2;
        setLocation(xPos, yPos);
    }
}
