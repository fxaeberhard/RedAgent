
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


/**
* Interface contenant tous les types de Blocks possibles
*/

public interface Sol {
    // Type SOL
    final int SOL = 0;
    // Type MOU
    final int MOU = 1;
    // Type MUR
    final int MUR = 2;
    // Type INDESTRUCTIBLE
    final int INDESTRUCTIBLE = 3;

    // Bonus FLAMME
    final int BONUSFLAMME = 4;
    // Bonus BOMBE
    final int BONUSBOMBE = 5;
    // Malus LENTEUR
    final int MALUSLENTEUR = 8;
    // Bonus VITESSE
    final int BONUSVITESSE = 9;
}
