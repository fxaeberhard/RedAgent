
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import javax.swing.*;
import java.awt.*;
import java.awt.image.* ;
import java.io.*;

/**
* Repr�sente le plateau de jeu au niveau type de sols
* par une matrice de Blocks
*/

public class Niveau implements Constantes {
    // La zone de jeu o� afficher les Blocks
    public static ZoneJeu zoneJeu;

    // Le tableau des noms des fichiers images
    String nomFichier[];
    // Le tabeau de Blocks
    Block carte[][];
    // Le tableau des types de Block
    int type[][];
    // Le tableau des images existantes
    Image image[];

    /**
    * Class Constructor
    */

    public Niveau() {
        // Cr�e la carte et initialise le niveau 1
        setCarte(1);
        initImagesFond();
    }

    /**
    * Initialise le niveau
    * @param numNiveau num�ro du niveau
    */

    public void setCarte(int numNiveau) {
        initCarte(numNiveau);
        chargerImages();
        initImagesFond();
    }

    /**
    * Initialise la zone de jeu
    * @param zj zone jeu
    */

    public static void init(ZoneJeu zj) {
        zoneJeu = zj;
    }

    /**
    * Initialise le Niveau en chargeant son fichier
    * @param numNiveau num�ro du niveau
    */

    public void initCarte(int numNiveau) {
        FileInputStream fis;
        ObjectInputStream in;
        
        // Ouvre le fichier correspondant au niveau et le charge
        try {
            fis = new FileInputStream("level/level" + numNiveau + ".lvl");
            in = new ObjectInputStream(fis);

            nomFichier = (String[])in.readObject();
            type = (int[][])in.readObject();

            in.close();
            fis.close();
        }
        catch(Exception ex) {
            new BoiteDialogue("Pas bien : Fichier non trouv� !");
            return;
        }
    }

    /**
    * Initialise le tableau de Blocks
    */

    public void initImagesFond() {
        carte = new Block[NBLIGNES][NBCOLONNES];

        // Charge les images correspondantes � la case
        for (int i = 0; i < NBLIGNES; i++)
            for(int j = 0; j < NBCOLONNES; j++)
                if (type[i][j] > 3)
                    carte[i][j] = new Block(image[1], type[i][j], j, i);
                else
                    carte[i][j] = new Block(image[type[i][j]], type[i][j], j, i);
    }


    /**
    * Initialise le tableau d'images
    */

    public void chargerImages() {
        image = new Image[nomFichier.length];

        // Charge les images correspondant au niveau
        for(int i = 0; i < nomFichier.length; i++) {
            image[i] = zoneJeu.load(nomFichier[i]);
        }
    }

    /**
    * D�truit le Block en (i, j)
    * return false si le Block n'est pas d�truit, true sinon
    */

    public boolean detruire(int i, int j) {
        // Empeche la destruction du tour
        if ((i <= 0) || (i >= NBLIGNES) || (j <= 0) || (j > NBCOLONNES))
            return false;
        // D�truit la case (i, j)
        else
            return carte[i][j].explose(image);
    }


    /**
    * Dit si le Block en (i, j) est destructible
    * return true si le Block est destructible, false sinon
    */

    boolean isDestructible(int j, int i) {
        // Empeche la destruction du contour
        if ((i <= 0) || (i >= NBLIGNES) || (j <= 0) || (j > NBCOLONNES))
            return false;
        // Dit si la case (i, j) est destructible
        return ((carte[i][j].type != 0) && (carte[i][j].type != 3));
    }

    /**
    * Repaint le Niveau dans le fond de la zone de jeu
    * @param g Contexte graphique du fond de la zone de jeu
    */

    public void paint(Graphics g) {
        // Repaint le fond case par case
        for(int i = 0; i < NBLIGNES; i++)
            for(int j = 0; j < NBCOLONNES; j++)
                carte[i][j].paint(g);
    }
}
