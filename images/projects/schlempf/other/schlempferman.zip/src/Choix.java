/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 * Modified by  Fran�ois-Xavier Aeberhard & Mikael Pelle
 */



import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
* Affiche une fen�tre permettant de choisir les images qui seront utilis�es
* pour cr�er un nouveau niveau
*/

public class Choix extends JFrame implements ActionListener {
    EditNiveau edit;
    Container contentPane;
    JPanel[] types = new JPanel[4];
    JPanel boutons;
    JLabel[] labels = new JLabel[5];
    JLabel titre;
    String[] entetes, sol, mou, mur, indes;
    JRadioButton[] jrbSol = new JRadioButton[6];
    JRadioButton[] jrbMou = new JRadioButton[5];
    JRadioButton[] jrbMur = new JRadioButton[4];
    JRadioButton[] jrbIndes = new JRadioButton[5];
    ButtonGroup bgSol, bgMou, bgMur, bgIndes;
    JLabel[] labelSol, labelMou, labelMur, labelIndes;
    ImageIcon[] solPic, mouPic, murPic, indesPic;
    JButton valider, annuler;

    /**
    * Class Constructor
    * Affiche la fen�tre
    */

    public Choix(EditNiveau edit) {
        super("Choix des images :");

        contentPane = getContentPane();
        contentPane.setLayout(new GridLayout(10,1));
        this.edit = edit;

        initStrings();
        initImages();

        for(int i=0; i<4; i++)
            labels[i] = new JLabel(entetes[i]);

        titre = new JLabel("Choisir un seul type d'�l�ments dans chaque liste :");
        contentPane.add(titre);

        creerGroupe(0, 6, jrbSol, labelSol, bgSol, solPic);
        creerGroupe(1, 5, jrbMou, labelMou, bgMou, mouPic);
        creerGroupe(2, 4, jrbMur, labelMur, bgMur, murPic);
        creerGroupe(3, 5, jrbIndes, labelIndes, bgIndes, indesPic);

        boutons = new JPanel();
        boutons.setLayout(new GridLayout(1, 2));
        boutons.add(valider = new JButton("Valider"));
        boutons.add(annuler = new JButton("Annuler"));
        contentPane.add(boutons);

        valider.addActionListener(this);
        annuler.addActionListener(this);

        setSize(500, 475);
        setResizable(false);
        centrer();
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }

    /**
    * Initialise les talbeaux de RadioButton et les groupes de boutons
    * @param numero Le numero de panel auquel seront ajoute les boutons
    * @param longueur La longueur du tableau
    * @param jrb Le tableau de JRadioButton associe
    * @param label Le tableau de label associe
    * @param bg Le groupe de boutons
    * @param pic Les images associ�es
    */

    void creerGroupe(int numero, int longueur, JRadioButton[] jrb, JLabel[] label, ButtonGroup bg, ImageIcon[] pic) {
        types[numero] = new JPanel();
        types[numero].setLayout(new FlowLayout());
        label = new JLabel[longueur];
        bg = new ButtonGroup();
        for(int i = 0; i<longueur; i++) {
            label[i] = new JLabel(pic[i]);
            jrb[i] = new JRadioButton();
            bg.add(jrb[i]);
            types[numero].add(label[i]);
            types[numero].add(jrb[i]);
        }
        jrb[0].setSelected(true);
        contentPane.add(labels[numero]);
        contentPane.add(types[numero]);
    }

    /**
    * G�re les clics sur les boutons
    */

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == valider) {
            String[] tabString = new String[4];

            tabString[0] = sol[getSelected(jrbSol)];
            tabString[1] = mou[getSelected(jrbMou)];
            tabString[2] = mur[getSelected(jrbMur)];
            tabString[3] = indes[getSelected(jrbIndes)];

            dispose();
            edit.setImages(tabString);
        }
        if (e.getSource() == annuler) {
            dispose();
        }
    }

    /**
    * Donne l'indice du RadioButton selectionn�
    * @param jrb Le tableau de JRadioButton
    * @param return L'indice de l'�l�ment s�lectionn�
    */

    int getSelected(JRadioButton[] jrb) {
        for(int i = 0; i < jrb.length; i++)
            if (jrb[i].isSelected())
                return i;
        return 0;
    }

    /**
    * Centre la fen�tre dans l'�cran
    */

    void centrer() {
        Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
        int largeurEcran = tailleEcran.width;
        int hauteurEcran = tailleEcran.height;
        int largeur = getSize().width;
        int hauteur = getSize().height;
        int xPos = (largeurEcran - largeur) / 2;
        int yPos = (hauteurEcran - hauteur) / 2;
        setLocation(xPos, yPos);
    }

    /**
    * Cr�e des tableaux d'images suivant les images disponibles
    */

    void initImages() {
        solPic = new ImageIcon[6];
        mouPic = new ImageIcon[7];
        murPic = new ImageIcon[4];
        indesPic = new ImageIcon[5];

        for(int i = 0; i < 6; i++)
            solPic[i] = new ImageIcon(sol[i]);

        for(int i = 0; i < 7; i++)
            mouPic[i] = new ImageIcon(mou[i]);

        for(int i = 0; i < 4; i++)
            murPic[i] = new ImageIcon(mur[i]);

        for(int i = 0; i < 5; i++)
            indesPic[i] = new ImageIcon(indes[i]);
    }

    /**
    * Cr�es les tableaux de String avec les noms des fichiers disponibles
    */

    void initStrings() {
        entetes = new String[] {
            "Types de sols",
            "Types de pierres molles",
            "Types de pierres dures",
            "Types d'elements indestructibles"
        };
        sol = new String[] {
            "fond/sol/carreau.gif",  "fond/sol/carreau2.gif",
            "fond/sol/carreau3.gif", "fond/sol/solglace.gif",
            "fond/sol/solmetal.gif", "fond/sol/fond.gif"
        };

        mou = new String[] {
            "fond/mou/fleur.gif",  "fond/mou/boneige.gif",
            "fond/mou/rocheh.gif", "fond/mou/bot1.gif",
            "fond/mou/bot2.gif",   "fond/mou/top1.gif",
            "fond/mou/top2.gif"
        };

        mur = new String[] {
            "fond/mur/bois.gif", "fond/mur/glacon.gif",
            "fond/mur/glacon2.gif", "fond/mur/metal.gif"
        };

        indes = new String[] {
            "fond/indestructible/blocmetal.gif",
            "fond/indestructible/epfl.gif",
            "fond/indestructible/ic.gif",
            "fond/indestructible/logo150.gif",
            "fond/indestructible/head.gif"
        };
    }
}
