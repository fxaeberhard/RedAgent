
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import javax.swing.*;
import java.awt.*;
import java.awt.image.* ;

/**
* G�re les flammes d'une bombe
*/

public class Flamme extends Canvas implements Constantes {
    // La zone de jeu o� afficher les flammes
	public static ZoneJeu zoneJeu;
    // Les noms des images des flammes
	public static String nomFichier[][];
    // Le centre de la flamme
    public static Image explosionC;
    // La flamme verticale
    public static Image explosionV;
    // La flamme horizontale
    public static Image explosionH;
    // G�re l'arr�t de la flamme � la premi�re pierre rencontr�e
    int explosion[];
    // La position du centre de la flamme   
    int i, j;
    
    /**
    * Class Constructor
    * Initialise la flamme (ses images en particulier)
    */

	public Flamme() {
    	super();

        // Les noms des images
        nomFichier = new String[][]{{"bombe/explo2.gif", "bombe/explo2h.gif", "bombe/explo2v.gif"}};
        
        // Charge les images des flammes       
        explosionC = zoneJeu.load(nomFichier[0][0]);
        explosionH = zoneJeu.load(nomFichier[0][1]);
        explosionV = zoneJeu.load(nomFichier[0][2]);
        
        // Initialise l'arret des flammes dans chaque direction
        explosion = new int[4];
        for(int i = 0; i < 4; i++)
            explosion[i] = 0;
    }

    /**
    * Initialise un pointeur sur la zone de jeu
    * @param zj Zone Jeu
    */

    public static void init(ZoneJeu zj) {
    	zoneJeu = zj;
    }
    
    /**
    * R�gle la position du centre de la flamme en fonction de la position
    * de la bombe associ�e
    */

    public void setPosition(int i, int j) {
        this.i = i;
        this.j = j;
    }
}
