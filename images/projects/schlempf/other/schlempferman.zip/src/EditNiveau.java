/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 * Modified by  Fran�ois-Xavier Aeberhard & Mikael Pelle
 */


import java.io.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
* Permet d'�diter un niveau pour le jeu, et de l'enregistrer
* en tant que fichier .lvl
*/

public class EditNiveau extends JFrame implements ActionListener, MouseListener, Constantes {
    Container contentPane;

    // Lien vers la fen�tre de choix des images
    Choix choix;
    JMenuBar menu = new JMenuBar();
    JMenu fichier = new JMenu ("Fichier");
    JMenu apropos = new JMenu ("?");

    JMenuItem ouvrir = new JMenuItem("Ouvrir");
    JMenuItem nouveau = new JMenuItem("Nouveau");
    JMenuItem enregisterSous = new JMenuItem("Enregister sous");
    JMenuItem quitter = new JMenuItem("Quitter");
    JMenuItem ap = new JMenuItem("A propos");
    JPanel damier;
    JLabel cases[][];

    JPanel panel2;
    JLabel[] choixImage;

    ButtonGroup group;
    JRadioButton[] jrb;
    ImageIcon[] icon;
    String[] bonus;
    int courant;
    // Le listener du groupe de radio boutons
    RadioListener myListener;
    int i1, i2, j1, j2;

    // Les types des Blocks de la carte
    int type[][];
    // Les noms de fichiers correspondant aux images
    String nomsFichiers[];

    /**
    * Class Constructor
    * Cr�e un editeur de niveau et affiche la fenetre
    */

    public EditNiveau() {
        super("Editeur de niveau");
        contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        fichier.add(nouveau);
        nouveau.addActionListener(this);

        fichier.add(ouvrir);
        ouvrir.addActionListener(this);

        fichier.add(enregisterSous);
        enregisterSous.addActionListener(this);

        fichier.add(quitter);
        quitter.addActionListener(this);

        apropos.add(ap);
        ap.addActionListener(this);

        fichier.setMnemonic(KeyEvent.VK_F);
        ouvrir.setMnemonic(KeyEvent.VK_O);
        nouveau.setMnemonic(KeyEvent.VK_N);
        enregisterSous.setMnemonic(KeyEvent.VK_S);
        quitter.setMnemonic(KeyEvent.VK_Q);

        menu.add(fichier);
        menu.add(apropos);
        setJMenuBar(menu);

        cases = new JLabel[NBLIGNES][NBCOLONNES];
        damier = new JPanel();

        damier.setLayout(new GridLayout(NBLIGNES,NBCOLONNES));
        damier.setSize(LONGUEUR,LARGEUR);
        damier.setOpaque(true);

        for(int i = 0; i < NBLIGNES; i++)
            for(int j = 0; j < NBCOLONNES; j++) {
                cases[i][j] = new JLabel();
                cases[i][j].setBorder(BorderFactory.createLineBorder(Color.black));
                cases[i][j].setPreferredSize(new Dimension(OFFSET, OFFSET));
                damier.add(cases[i][j]);
            }
        contentPane.add(damier, BorderLayout.WEST);

        icon = new ImageIcon[10];
        nomsFichiers = new String[10];
        type = new int[NBLIGNES][NBCOLONNES];
        panel2 = new JPanel();
        panel2.setLayout(new GridLayout(10, 2));
        contentPane.add(panel2, BorderLayout.EAST);
        choixImage = new JLabel[10];
        jrb = new JRadioButton[10];
        group = new ButtonGroup();

        myListener = new RadioListener();
        for(int i = 0; i < 10; i++) {
            jrb[i] = new JRadioButton();
            choixImage[i] = new JLabel();
            jrb[i].addActionListener(myListener);
            group.add(jrb[i]);
        }

        setSize(LONGUEUR + 80 + 4, LARGEUR + 52);
        centrer();
        setResizable(false);
        setVisible (true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
            }
        });
    }

    /**
    * Ajoute le panel de droite sur la fenetre
    */

    public void dessiner(JLabel lab) {
        this.getContentPane().add(lab);
    }

    /**
    * G�re les clics dans les menus
    */

    public void actionPerformed(ActionEvent e) {
        JMenuItem menu;
        menu = (JMenuItem)e.getSource();

        if (menu == nouveau) {
            choix = new Choix(this);
            choix.setVisible(true);
        }

        if (menu == enregisterSous) {
            JFileChooser fc = new JFileChooser();
            LevelFilter lf = new LevelFilter();
            fc.addChoosableFileFilter(lf);

            int returnVal = fc.showSaveDialog(this);
            if (returnVal == JFileChooser.APPROVE_OPTION) {
                    File file = fc.getSelectedFile();

                // Interdit d'avoir quelque chose dans chaque coin
                if (type[1][1] != 0) type[1][1] = 0;
                if (type[12][1] != 0) type[11][1] = 0;
                if (type[1][17] != 0) type[1][17] = 0;
                if (type[11][17] != 0) type[11][17] = 0;

                if (lf.accept(file))
                    enregistrer("level/" + file.getName());
                else
                    enregistrer("level/" + file.getName() + ".lvl");
            }
        }

        if (menu == ouvrir) {
            JFileChooser fc = new JFileChooser();
            LevelFilter lf = new LevelFilter();
            fc.addChoosableFileFilter(lf);

            int returnVal = fc.showOpenDialog(this);

            if (returnVal == JFileChooser.APPROVE_OPTION) {
                File file = fc.getSelectedFile();
                if (lf.accept(file))
                    ouvrir("level/" + file.getName());
                else
                    ouvrir("level/" + file.getName() + ".lvl");
            }
        }

        if (menu == quitter) {
            dispose();
        }

        if (menu == ap) {
            BoiteDialogue message = new BoiteDialogue("Editeur de Niveau");
        }
    }

    /**
    * Ouvre un fichier
    */

    public void ouvrir(String nom) {
        FileInputStream fis;
        ObjectInputStream in;
        try {
            fis = new FileInputStream(nom);
            in = new ObjectInputStream(fis);

            nomsFichiers = (String[])in.readObject();
            type = (int[][])in.readObject();

            in.close();
            fis.close();

            setImages();
        }
        catch(Exception ex) {
            new BoiteDialogue("Pas bien : Fichier non trouv�");
            return;
        }
    }

    /**
    * Enregistre un fichier
    */

    public void enregistrer(String nom) {
        FileOutputStream fos;
        ObjectOutputStream out;
        try {
            fos = new FileOutputStream(nom);
            out = new ObjectOutputStream(fos);

            out.writeObject(nomsFichiers);
            out.writeObject(type);

            out.close();
            fos.close();
        }
        catch(Exception ex) {
            new BoiteDialogue("Erreur quelconque !");
            return;
        }
    }

    /**
    * G�re les clics de souris sur la niveau � cr�er
    */

    public void mousePressed(MouseEvent e) {
        Point p = e.getPoint();
        // R�cup�re la ligne et la colonne du clic
        i1 = (p.y - 52) / 32;
        j1 = (p.x - 4) / 32;
    }

    public void mouseMoved(MouseEvent e) {}

    public void mouseDragged(MouseEvent e) {}

    public void mouseClicked(MouseEvent e) {
        Point p = e.getPoint();
        // R�cup�re la ligne et la colonne du clic
        i1 = (p.y - 52) / 32;
        j1 = (p.x - 4) / 32;
    }

    public void mouseReleased(MouseEvent e) {
        Point p = e.getPoint();
        i2 = (p.y - 52) / 32;
        j2 = (p.x - 4) / 32;
        // R�cup�re la zone � remplir
        if (i2 < i1) {
            int aux = i1;
            i1 = i2;
            i2 = aux;
        }
        if (j2 < j1) {
            int aux = j1;
            j1 = j2;
            j2 = aux;
        }

        // Remplit la zone s�lectionn�e
        for(int i = i1; i <= i2; i++)
            for(int j = j1; j <= j2; j++)
                if ((i <= 0) || (i >= 12) || (j <= 0) || (j >= 18))
                    continue;
                else {
                    cases[i][j].setIcon(icon[courant]);
                    type[i][j] = courant;
                }
    }

    public void mouseEntered(MouseEvent e) {}

    public void mouseExited(MouseEvent e) {}

    /**
    * Charge les images apres ouverture d'un fichier
    */

    void setImages() {
        // Initialise le tableau d'images
        for(int i = 0; i < 10; i++)
            icon[i] = new ImageIcon(nomsFichiers[i]);

        for(int i = 0; i < NBLIGNES; i++)
            for(int j = 0; j < NBCOLONNES; j++)
                cases[i][j].setIcon(icon[type[i][j]]);

        initPanelChoix();
        addMouseListener(this);
    }

    /**
    * Charge les images r�cup�r�es du chois des images
    * @param tab Les images r�cup�r�es
    */

    void setImages(String[] tab) {
        for(int i = 0; i < NBLIGNES; i++)
            for(int j = 0; j < NBCOLONNES; j++)
                type[i][j] = 0;
        initTour();

        bonus = new String[] {
                "bonus/bonusflamme.gif",
                "bonus/bonusbombe.gif",
                "bonus/bonustelec.gif",
                "bonus/bonuslanceur.gif",
                "bonus/bonuscrane.gif",
                "bonus/bonuspatin.gif"
        };

        for(int i = 0; i < 4; i++) {
            icon[i] = new ImageIcon(tab[i]);
            nomsFichiers[i] = new String(tab[i]);
        }

        for(int i = 4; i < 10; i++) {
            icon[i] = new ImageIcon(bonus[i - 4]);
            nomsFichiers[i] = new String(bonus[i - 4]);
        }

        for(int i = 0; i < NBLIGNES; i++)
            for(int j = 0; j < NBCOLONNES; j++)
                cases[i][j].setIcon(icon[type[i][j]]);

        initPanelChoix();
        addMouseListener(this);
    }

    /**
    * Initialise le panel de choix sur la droite de la fen�tre
    */

    void initPanelChoix() {
        panel2.removeAll();

        // Initialise les radio boutons de chois d'image courante
        for(int i = 0; i < 10; i++) {
            panel2.add(jrb[i]);
            choixImage[i].setIcon(icon[i]);
            panel2.add(choixImage[i]);
        }
        jrb[0].setSelected(true);
        repaint();
    }

    /**
    * Initialise le tour du plateau de jeu avec le type indestructible
    */

    void initTour() {
        // Remplit les deux lignes extr�mes
        for(int i = 0; i < NBCOLONNES; i++) {
            type[0][i] = 3;
            type[12][i] = 3;
        }
        // Remplit les deux colonnes extr�mes
        for(int i = 1; i < NBLIGNES - 1; i++) {
            type[i][0] = 3;
            type[i][18] = 3;
        }
    }

    /**
    * G�re la selection d'un nouveau Radio Bouton
    */

    class RadioListener implements ActionListener {
        public void actionPerformed(ActionEvent e) {
            // R�cup�re le nouvel �l�ment s�lectionn�
            courant = getSelected();
        }
    }

    /**
    * Retourne l'indice du radio bouton selectionne, 0 en cas d'erreur
    */

    int getSelected() {
        for(int i = 0; i < 10; i++)
            if (jrb[i].isSelected())
                return i;
        return 0;
    }

    /**
    * Centre la fen�tre dans l'�cran
    */

    void centrer() {
        Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
        int largeurEcran = tailleEcran.width;
        int hauteurEcran = tailleEcran.height;
        int largeur = getSize().width;
        int hauteur = getSize().height;
        int xPos = (largeurEcran - largeur) / 2;
        int yPos = (hauteurEcran - hauteur) / 2;
        setLocation(xPos, yPos);
    }

    public static void main(String args[]) {
        EditNiveau en = new EditNiveau();
    }
}
