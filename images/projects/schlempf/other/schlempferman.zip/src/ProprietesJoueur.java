
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.awt.*;
import java.awt.event.*;

/**
* Toutes les propri�t�s "physiques" du joueur: couleurs et touches
*/

public class ProprietesJoueur {
    // La couleur du perso
    Color couleur;

    // Les touches contr�lant le joueur
    public int up;
    public int down;
    public int left;
    public int right;
    public int space;
    public int enter;
    public int key;

    /**
    * Class Constructor
    */

    public ProprietesJoueur(Color c) {
        couleur = c;
    }

    /**
    * Configure les touches du joueur
    */

    void setKeys() {
        key = 0;

        up    = KeyEvent.VK_UP;
        down  = KeyEvent.VK_DOWN;
        left  = KeyEvent.VK_LEFT;
        right = KeyEvent.VK_RIGHT;
        space = KeyEvent.VK_SPACE;
        enter = KeyEvent.VK_ENTER;
    }
}
