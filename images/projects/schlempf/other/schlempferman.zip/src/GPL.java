/**
 * <p>Titre : Schlempferman Java 2004 </p>
 * <p>Description : Java Game </p>
 * <p>Copyright : 2004 </p>
 * <p>Soci�t� : EPFL SIN </p>
 * @author Fran�ois-Xavier Aeberhard & Mikael Pelle
 * @version 1.0
 */

import java.io.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

/**
 * This window contains informations about the GNU GPL
 * */
public class GPL
    extends JFrame {

  JEditorPane jEditorPane = new JEditorPane();
  JScrollBar scrollBar = new JScrollBar();

  /**
   * Constructs the window:<br/>
   * JEditorPane is used to show the text.<br/>
   * JScrollBar allows us to scroll the text,
   */
  public GPL() {
    /**
     * Sets the title of the window
     * */
    super("GNU-GPL");
    try {
      jbInit();
    }
    catch (Exception e) {
      e.printStackTrace();
    }
  }

  /**
   * Initialization of the window
   * */
  private void jbInit() throws Exception {
    final int l = 520; // Window Width
    final int h = 510; // Window Height
    jEditorPane.setSize(l - 25, h);
    jEditorPane.setEditable(false);
    jEditorPane.setText(AboutText());
    scrollBar.setBounds(new Rectangle(l - 25, 0, 25, h - 30));
    scrollBar.addAdjustmentListener(new AdjustmentListener() {
      public void adjustmentValueChanged(AdjustmentEvent e) {
        jEditorPane.setBounds(new Rectangle(0, 2 - 48 * e.getValue(),
                                            l - 25, AboutText().length()));
      }
    });
    // add all components to the Pane
    this.getContentPane().add(jEditorPane, null);
    this.getContentPane().add(scrollBar, null);
    this.getContentPane().setLayout(null);
    this.setResizable(false);
    this.setSize(l, h);
    this.setLocationRelativeTo(null);
    this.setVisible(true);
  }

  /**
   * Method to read a file and convert it to a string
   *
   * @return aboutString converted text file to String
   */
  public String AboutText() {
    String aboutString = "";

    try {
      FileReader about = new FileReader("GNU-GPL.txt");
      BufferedReader buffer = new BufferedReader(about);
      String aboutTemp = buffer.readLine();
      while (aboutTemp != null) {
        if (aboutTemp != null) {
          aboutString = aboutString + "\n" + aboutTemp;
          aboutTemp = buffer.readLine();

        }
      }
    }
    catch (IOException e) {
    }
    return aboutString;
  }
}
