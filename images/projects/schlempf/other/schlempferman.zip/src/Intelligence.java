/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


/**
 * Contr�le par l'ordinateur d'un personnage
 */
import java.util.*;

public class Intelligence
    implements Runnable, Constantes {

  Plateau plateau;
  // G�re le plateau de jeu au niveau type de sols
  Niveau niveau;
  // Le personnage ennemi
  Perso ennemi;
  // Le personnage g�r�
  Perso gentil;

  // Se trouve-t-on sur une bombe que l'on vient de placer ?
  int bombePosee;
  int lPositionBombe, cPositionBombe;

  /**
   * Class Constructor
   *
   */

  public Intelligence(Plateau table, Perso moi, Perso lui, Niveau monde) {
    plateau = table;
    gentil = moi;
    ennemi = lui;
    niveau = monde;
    bombePosee = 0;

    System.gc();
    //removed in race condition patch [L.E]
    //this hasn't anything to do with the race condition, but it's still wrong
    //since the Thread is started in the main game loop
    //new Thread(this).start();
  }

  /**
   * Le thread principal du personnage
   */

  public void run() {
    // Change la position du personnage tant que la partie dure
    while (!plateau.partie.finPartie()) {
      if (gentil.vivant) {
        agir();

      }
      try {
        Thread.sleep(80);
      }
      catch (Exception e) {
        ;
      }
    }
  }

  /**
   * fait se deplacer le joueur
   * @param d HAUT, BAS, GAUCHE, DROITE
   */

  void deplacement(int d) {
    switch (d) {
      case 0:
        gentil.propj.key = gentil.propj.up;
        break;
      case 1:
        gentil.propj.key = gentil.propj.down;
        break;
      case 2:
        gentil.propj.key = gentil.propj.left;
        break;
      case 3:
        gentil.propj.key = gentil.propj.right;
        break;
      default:
        ;
    }
  }

  /**
   * fait poser une bombe au joueur
   */

  void poseBombe() {
    //condition pulled up in race condition patch [L.E]
    if (gentil.nbBombe > 0) {
      plateau.envoyer("POSE", gentil.coord.x, gentil.coord.y);
      gentil.poseBombe(gentil.coord.x, gentil.coord.y);
    }
  }

  /**
   * arrete le joueur
   */

  void stop() {
    gentil.propj.key = 0;
  }

  /**la liste ouverte tous les nodes envisag�s dans le path finder
   *
   */

  Vector listeOuverte;
  /**la liste fermee contient tous les nodes test�s
   *
   */
  Vector listeFermee;
  /**La m�thode agir g�re la pose de bombe si les joueur est sur la m�me case que l'ennemi ou lance le pathfinder
   *
   */

  void agir() {
    //calcul des positions de joeurs
    int xGentil = (int) (this.gentil.position.getX() * this.niveau.type.length /
                         niveau.LARGEUR);
    int yGentil = (int) (this.gentil.position.getY() *
                         this.niveau.type[0].length / niveau.LONGUEUR);
    int xEnnemi = (int) (this.ennemi.position.getX() * this.niveau.type.length /
                         niveau.LARGEUR);
    int yEnnemi = (int) (this.ennemi.position.getY() *
                         this.niveau.type[0].length / niveau.LONGUEUR);
    //Si le joueur est sur l'ennemi, il pose une bombe
    if (xGentil == xEnnemi & yGentil == yEnnemi) {
      this.poseBombe();
    }
    //Sinon il lance le pathfinder
    //   cr�e un node
    //   calcul le cout de d�placement depuis le d�part
    //   estime le cout de d�placement jusqu'� larriv�e
    //   fait le total des deux
    //   l'ajoute � la liste ouverte
    //
    //   lance la m�thode pathfinder()
    else {
      node depart = new node(xGentil, yGentil, null);
      depart.f = 0;
      depart.g = Math.abs(xEnnemi - xGentil) + Math.abs(yEnnemi - yGentil);
      depart.setH();

      this.listeOuverte = new Vector();
      this.listeFermee = new Vector();

      listeOuverte.add(depart);
      pathFinder();
    }
  }
  /**La m�thode pathFinder() est un pathfinder de type a*, voir � l'int�rieur du code pour les commentaires
   *
   */

  void pathFinder() {

    int xEnnemi = (int) (this.ennemi.position.getX() * this.niveau.type.length /
                         niveau.LARGEUR);
    int yEnnemi = (int) (this.ennemi.position.getY() *
                         this.niveau.type[0].length / niveau.LONGUEUR);

    int xGentil = (int) (this.gentil.position.getX() * this.niveau.type.length /
                         niveau.LARGEUR);
    int yGentil = (int) (this.gentil.position.getY() *
                         this.niveau.type[0].length / niveau.LONGUEUR);

    //f= cout de d�placement depuis le d�part
    //g=estimation du cout de d�placement jusqu'� l'arriv�e
    //h= total des deux
    //parent = le noeud vers lequel pointe le noeud

    //prend le node avec le h le plus bas de la liste ouverte, prend le g s'il y a �galit�
    node courant = (node) listeOuverte.get(0);
    for (int i = 0; i < this.listeOuverte.size(); i++) {
      if ( ( ( ( (node)this.listeOuverte.get(i)).h == courant.h) &
            ( ( (node)this.listeOuverte.get(i)).g > courant.g)) ^
          ( ( (node)this.listeOuverte.get(i)).h < courant.h)) {
        courant = (node) listeOuverte.get(i);
      }
    }
    //ajoute ce noeud � la liste fermee et l'enl�ve de la liste ferm�e
    this.listeFermee.add(courant);
    this.listeOuverte.remove(courant);

    //cr�e et ajoute tous les noeuds avoisinant � la liste ouverte, si ils ne sont pas d�j� sur la liste ferm� ou inaccessibles.
   // S'il existe d�j� dans la liste ouverte, le remplace seulement si le cout de d�placement
    //est plus petit.
    for (int i = -1; i < 2; i = i + 2) {
      for (int f = 0; f < 2; f++) {
        node teste = courant;
        switch (f) {
          case 0:
            teste = new node(courant.x + i, courant.y, courant);
            break;
          case 1:
            teste = new node(courant.x, courant.y + i, courant);
            break;
        }
        if (gentil.testCoord(teste.y, teste.x) & !isInListe(listeFermee, teste)) {
          if (!this.isInListe(this.listeOuverte, teste)) {
            teste.f = courant.f + 1;
            teste.g = Math.abs(xEnnemi - teste.x) + Math.abs(yEnnemi - teste.y);
            teste.setH();
            this.listeOuverte.add(teste);
          }
          else if (getFromList(this.listeOuverte, teste).g < teste.g) {
            this.listeOuverte.remove(getFromList(this.listeOuverte, teste));
            this.listeOuverte.add(teste);
          }
        }
      }
    }
    //Si la position de l'ennemi est dans la liste fermee, reprend tous les noeuds de parents en parents.
    //pour revenire au d�part et bouge le perso
    //sinon, relance la m�thode pathfinder()
    if (!isInListe(listeFermee, new node(xEnnemi, yEnnemi, null))) {
      try {
        pathFinder();
      }
      catch (Exception ex) {
      }
    }
    else {
      node current = (node) listeFermee.lastElement();
      boolean retourFini = false;
      while (!retourFini) {
        if (! (current.parent.x == xGentil & current.parent.y == yGentil)) {
          current = current.parent;
        }
        else {
          retourFini = true;
        }
      }
      if (current.x > xGentil) {
        this.deplacement(3);
      }
      else if (current.x < xGentil) {
        this.deplacement(2);
      }
      else if (current.y > yGentil) {
        this.deplacement(1);
      }
      else if (current.y < yGentil) {
        this.deplacement(0);
      }
    }
  }
  /** is in liste dit si un noeud est d�j� dans la liste
   *
   * @param liste la liste dans laquelle le noeud est cherch�
   * @paramle test noeud test�
   *
   * @return true si le noeud est dans la liste
   */

  boolean isInListe(List liste, node test) {
    boolean result = false;
    for (int i = 1; i < liste.size(); i++) {
      if ( ( ( (node) liste.get(i)).x == test.x) & ( ( (node) liste.get(i)).y == test.y)) {
        result = true;
      }
    }
    return result;
  }

  /**retourne un noeud de la liste
   * @param liste la liste du noeud recherch�
   * @param test le noeud recherch�
   * @return le node recherch�
   */

  node getFromList(List liste, node test) {
    node result = null;
    for (int i = 1; i < liste.size(); i++) {
      if ( ( ( (node) liste.get(i)).x == test.x) &
          ( ( (node) liste.get(i)).y == test.y)) {
        result = (node) liste.get(i);
      }
    }
    return result;
  }

}
/** l'objet node est une case du terrain
 *
 */

class node {
  /**position en x du node
   *
   */

  int x;
  /**position en y du node
   *
   */

  int y;

  /**node vers lequel le node pointe
   *
   */

  node parent;
  /**cout de d�placment pour arriver au node
   *
   */

  int f;
  /** cout de d�placement estim� jusqu'� l'arriv�e
   *
   */
  int g;
  /**h = f+g
   *
   */

  int h;
  /** Constructeur
   *
   * @param x int position en x
   * @param y int position en y
   * @param parent node le noeud vers lequel le noeud courant pointe
   * @return Constructeur
   */

  node(int x, int y, node parent) {
    this.x = x;
    this.y = y;
    this.parent = parent;
  }

  void setH() {
    this.h = this.f + this.g;
  }
}
