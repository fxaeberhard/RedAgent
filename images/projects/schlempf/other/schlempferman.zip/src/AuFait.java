/**
 * <p>Titre : Schlempferman Java 2004 </p>
 * <p>Description : Java Game </p>
 * <p>Copyright : 2004 </p>
 * <p>Soci�t� : EPFL SIN </p>
 * @author Fran�ois-Xavier Aeberhard & Mikael Pelle
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
 * Au fait...
 */

public class AuFait
    extends JFrame
    implements ActionListener {
  Container contentPane;
  Label l;
  Button b;
  TextField t;

  double note;
  boolean alive = true;

BConfigClient parent;
  /**
   * Class Constructor
   *
   * @param title le titre de la fen�tre
   * @param note la note esp�r�e
   * @param parent le BConfigClient qui a lanc� la fen�tre
   */

  AuFait(String title, double note,BConfigClient  parent ) {
    super(title);
    this.parent=parent;
    this.note = note;
    contentPane = getContentPane();
    contentPane.setLayout(new BorderLayout());

    contentPane.add(l = new Label(
        "Quelle note d�sirez-vous � votre projet (1-6) ?"), BorderLayout.NORTH);
    contentPane.add(t = new TextField(String.valueOf(note)),
                    BorderLayout.CENTER);
    contentPane.add(b = new Button("Valider"), BorderLayout.SOUTH);

    t.addActionListener(this);
    b.addActionListener(this);

    setBounds(calculBounds());
    setResizable(false);
    setVisible(true);

    addWindowListener(new WindowAdapter() {
      public void windowClosing(WindowEvent e) {
        removeAll();
        dispose();
      }
    });
  }

  /**
   * G�re les clics sur les boutons. Si la valeur entr�e est correcte, ferme la fen�tre et stock la valeur,
   * sinon demande d'entrer une valeur possible
   *
   * @param e l'actionevent qui lance la m�thode
   */


  public void actionPerformed(ActionEvent e) {
    if (e.getSource() == b) {
      try {
        note = Double.parseDouble(t.getText());
      }      catch (NumberFormatException ex) {
        l.setText("Vous devez entrer un nombre");
      }
      if  (note >= 0 ^ note <= 6) {
        this.l.setText(
            "Vous devez entrer une note entre 0 et 6");
      }
      else if (note == 6) {
        this.l.setText("Faut pas r�ver... ;-)");
      }
      else {
        this.parent.noteEntree=note;
        removeAll();
        dispose();
      }
      contentPane.remove(l);
      contentPane.add(l, BorderLayout.NORTH);

    }

  }

  /**
   * Cherche les dimensions de l'�cran, et centre la fen�tre
   */

  Rectangle calculBounds() {
    Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
    int le = d.width;
    int he = d.height;
    int l = 300;
    int h = 100;
    int xPos = (le - l) / 2;
    int yPos = (he - h) / 2;

    return new Rectangle(xPos, yPos, l, h);
  }
}
