/**
 * <p>Titre : Schlempferman Java 2004 </p>
 * <p>Description : Java Game </p>
 * <p>Copyright : 2004 </p>
 * <p>Soci�t� : EPFL SIN </p>
 * @author Fran�ois-Xavier Aeberhard & Mikael Pelle
 * @version 1.0
 */

import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
* A propos
*
*/


public class About extends JFrame implements ActionListener {
    Container contentPane;
    Label l;
    Button b;

    /**
    * Class Constructor
    *
    * @param msg le String du message affich� dans la fen�tre
    *
    */

    About(String msg) {
        this("A propos", msg);
    }

    /**
    * Class Constructor
    *
    *  @param title le titre de la fen�tre
    * @param msg le message affich� dans la fen�tre
    */

    About(String title, String msg) {
        super(title);
        contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        contentPane.add(l = new Label(msg), BorderLayout.NORTH);
        contentPane.add(b = new Button(" OK "), BorderLayout.SOUTH);

        b.addActionListener(this);
        setBounds(calculBounds());
        setResizable(false);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                removeAll();
                dispose();
            }
        });
    }

    /**
    * G�re les clics sur les boutons
    */

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b) {
            removeAll();
            dispose();
        }
    }

    /**
    * Cherche les dimensions de l'�cran, et centre la fen�tre
    */

    Rectangle calculBounds() {
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        int le = d.width;
        int he = d.height;
        int l = 480;
        int h = 80;
        int xPos = (le - l) / 2;
        int yPos = (he - h) / 2;

        return new Rectangle(xPos, yPos, l, h);
    }
}
