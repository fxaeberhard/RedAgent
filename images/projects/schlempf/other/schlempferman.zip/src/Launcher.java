/**
 * Launcher.java
 * Author:	Eyer Leander
 * Date:	09.05.2004
 */

import java.io.*;
import java.util.Date;

/**
 * Advanced Launcher class. This class initializes a test case for the Schlempferman Project.
 */
public class Launcher {

	/** Semaphore used to synchronize the outputstream pipes **/
	private Object semaphore = new Object();

	/** Control switch to replace the deprecated stop() method calls on the pipe threads **/
	private boolean[] alive = new boolean[3];

	/** Subprocesses **/
	private Process[] processes = new Process[3];

	/** Controll variable for the Shutdown Hook to check wherever or not the subprocesses have to be destroyed **/
	private boolean exitedCorrectly = false;

	/** Control switch that controls the logging **/
    private boolean doLog = false;

	/** PrintWriter for Log output **/
	private PrintWriter logWriter;

	/** Init Point **/
	public static void main(String[] args) {
		boolean doLog = false;
		if ((args.length != 0) && (args [0].equals("log")))
			doLog = true;
		new Launcher(doLog);
	}

	/** Creates the Launcher **/
	public Launcher(boolean doLog) {
		System.out.println("Schlempferman Launcher by Eyer Leander");
		addShutdownHook();
        this.doLog = doLog;
		if (doLog) {
			try {
				File logFile = new File("log.txt");
				if (logFile.exists() == false)
					logFile.createNewFile();
				logWriter = new PrintWriter(new FileWriter(logFile));
				logWriter.println("Bomber Man Output Log");
				logWriter.println("Created on " + new Date());
				logWriter.println("---------------------");


				System.out.println(" > File logging activated, log file is " + logFile.getAbsolutePath());
			} catch (Exception e) {
				System.out.println("Creation of Log File failed: ");
				e.printStackTrace(System.out);
				doLog = false;
			}
		}

		try {

			startProcesses();
			redirectOutputStreams();
			waitForTermination();

			System.out.println("-- Exit");
			exitedCorrectly = true;

			if (logWriter != null) {
				logWriter.flush();
				logWriter.close();
				logWriter = null;
			}
			System.exit(0);
		} catch (Exception e) {
			e.printStackTrace(System.err);
		}
	}

	/** This method ensures that all child processes are terminated when this process is terminated **/
	private void addShutdownHook() {
		Runtime.getRuntime().addShutdownHook(new Thread(new Runnable() {
			public void run() {
				if (exitedCorrectly)
					return;
				for (int i = 0; i < 3; i++) {
					if ((processes[i] != null) && (alive[i]))
						processes[i].destroy();
				}
			}
		}));
	}

	/** This method starts the three subprocesses **/
	private void startProcesses() throws IOException {
		Runtime executer = Runtime.getRuntime();

		System.out.println("> starting server process");
		processes[0] = executer.exec("java BServeur startport=10000 portrange=2");
		alive[0] = true;
		waitOneSecond();

		System.out.println("> starting AI client process");
		processes[1] = executer.exec("java BClient port=10000 typ=ordinateur");
		alive[1] = true;
		waitOneSecond();

		System.out.print("> starting Humain client process");
		processes[2] = executer.exec("java BClient typ=humain port=10000 launch=true");
		alive[2] = true;
	}

	/** Help Method that encapsulates the waiting for one second **/
	private static void waitOneSecond() {
		try {
			Thread.sleep(1000);
		} catch (Exception e) {
		}
	}

	/** Enables the output of the child processes to appear on this processes output terminal **/
	private void redirectOutputStreams() {
		for (int i = 0; i < processes.length; i++) {
			InputStream input = processes[i].getInputStream();	//This input stream is piped to the outputstream of the process
			BufferedReader reader = new BufferedReader(new InputStreamReader(input));
			Pipe pipe = new Pipe(i, reader);
			pipe.start();
		}
	}

	/**
	 * Subclass that implements the pipe between the output streams of the sub processes and the output stream
	 * of the master process
	 */
	class Pipe extends Thread {
		/** Index of the process this Pipe is responsible for **/
		int processIndex;
		/** Reader that is connected to the processes Output stream **/
		BufferedReader reader;

		/** Create the pipe **/
		public Pipe(int processIndex, BufferedReader reader) {
			this.processIndex = processIndex;
			this.reader = reader;
		}

		/**
		 * This method does all the work:
		 * while the associated process is still alive, wait for input and redirect it to the standart output stream
		 */
		public void run() {
			while (alive[processIndex]) {
				try {
					String line = reader.readLine();
					if (line == null)
						continue;

					synchronized (semaphore) {
						System.out.println(" S" + (processIndex + 1) + "> " + line);
						if (doLog)
							logWriter.println(" S" + (processIndex + 1) + "> " + line);
					}
					Thread.yield();
				} catch (Exception e) {
				}
			}
		}
	}

	/** Wait for the termination of the sub processes **/
	private void waitForTermination() {
		//create Threads that register the termination of the client processes
		for (int i = 0; i < 3; i++) {
			final int index = i;
			new Thread(new Runnable() {
				public void run() {
					try {
						processes[index].waitFor();
					} catch (Exception e) {
					}
					alive[index] = false;
				}
			}).start();
		}

		//wait for humain processes to terminate
		while (true) {
			boolean allExited = true;
			for (int i = 0; i < alive.length; i++) {
				if (alive[i])
					allExited = false;
			}
			if (allExited)
				break;

			try {
				Thread.sleep(1000);
			} catch (Exception e) {
			}
		}
	}

}
