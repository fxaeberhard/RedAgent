
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.awt.*;
import java.awt.image.*;

/**
* Cr�e un contexte graphique pour la zone de jeu
* Permet de g�rer un premier plan et un arri�re-plan
*/

public class ZoneJeu extends Canvas implements Constantes {
    int hauteur;
    int largeur;
    // Image de fond
    Image fond ;
    // Contexte graphique de l'image de fond
    public Graphics gfond;
    // Image du premier plan
    Image buffer;
    // Contexte graphique du premier plan
    Graphics gbuffer;
    // Contexte graphique de la zone de jeu
    public Graphics gc;
    // Tracker pour charger les images
    MediaTracker tracker;
    // Toolkir pour charger l'image
    Toolkit toolkit;

    /**
    * Class Constructor:
    * Initialise les variables zoneJeu des classes Perso, Niveau...
    * Initialise la taille de la zone de jeu avec des valeurs par d�faut
    */

    public ZoneJeu() {
        // Initialisation du pointeur sur la zone de jeu

        Perso.init(this);
        Niveau.init(this);
        Block.init(this);
        Bombe.init(this);
        Flamme.init(this);

        // Initialisation de la taille de la zone de jeu
        largeur = LONGUEUR;
        hauteur = LARGEUR;
        setSize(largeur, hauteur);

        tracker = new MediaTracker(this);
        toolkit = Toolkit.getDefaultToolkit();
    }

    /** Class Constructor
    * Initialise les variables zoneJeu des classes Perso, Niveau...
    * Initialise la taille de la zone de jeu suivant les valeurs
    * @param hauteur  hauteur de la fen�tre
    * @param largeur  largeur de la fen�tre
    */

    public ZoneJeu(int hauteur, int largeur) {
        this.hauteur = hauteur;
        this.largeur = largeur;
        setSize(largeur, hauteur);

        tracker = new MediaTracker(this);
        toolkit = Toolkit.getDefaultToolkit();
    }

    /**
    * Initialise les contextes graphiques de la zone de jeu
    */

    public void init() {
        // Cr�ation des images et des graphiques li�s aux images
        buffer = createImage(largeur, hauteur);
        fond = createImage(largeur, hauteur);
        gc = getGraphics();
        gfond = fond.getGraphics();
        gbuffer = buffer.getGraphics();
    }

    /**
    * Charge une image
    * @param nomFichier Nom de l'image a charger
    * return  : L'image correspondant au param�tre
    */

    public Image load(String nomFichier) {
        Image retour ;

        //  Chargement d'une image � partir de son nom de fichier
        retour = toolkit.getImage(nomFichier);
        tracker.addImage(retour, 0);
        try {
            tracker.waitForAll();
        }
        catch(Exception e) {
            return null;
        }

        return retour ;
    }

    /** Charge une image avec un filtre de couleur
    * @param nomFichier Nom de l'image a charger
    * @param cci Filtre de couleur
    * return  : L'image filtr�e correspondant au param�tre
    */

    public Image load(String nomFichier, ColorChangeImage cci) {
        Image retour;
        Image src = toolkit.getImage(nomFichier);;
        // Chargement d'une image avec un filtre de couleur
        retour = toolkit.createImage(new FilteredImageSource(src.getSource(), cci));
        tracker.addImage(retour, 0);
        try {
            tracker.waitForAll();
        }
        catch(Exception e) {
            return null;
        }

        return retour;
    }

    /**
    *Affiche une image au premier plan
    * @param i Image a afficher
    * @param x oordonn�e horizontale
    * @param y Coordonn�e verticale
    */

    public void drawImage(Image i, int x, int y) {
        // Met l'image i dans le buffer
        gbuffer.drawImage(i, x, y, this);
    }

    /**
    * Repaint la zone de jeu
    * @param g  Contexte graphique de la zone de jeu
    */

    public void paint(Graphics g) {
        // Affiche l'image dans le Canvas
        if (buffer == null) return;
        g.drawImage(buffer, 0, 0, this);
    }

    /**
    * Efface la zone de jeu
    */

    public void erase() {
        gbuffer.drawImage(fond, 0, 0, this);
    }

    /**
    * Rafraichit la zone de jeu
    * @param g  Contexte graphique de la zone de jeu
    */

    public void update(Graphics g) {
        paint(g);
    }
}
