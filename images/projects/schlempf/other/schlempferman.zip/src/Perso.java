/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */

import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.util.*;
import java.awt.event.*;

/**
 * G�re un personnage:
 * D�placements
 * Pose de bombes
 * R�cup�ration des bonus
 */

public class Perso
    extends Joueur
    implements Constantes, Sol {
  // La zone de jeu o� �volue le perso
  public static ZoneJeu zoneJeu;

  // Le plateau de jeu
  public static Plateau plateau;
  ;

  // Les fichiers images
  String nomFichier;
  // Les fichiers de l'explosion
  String fichierExplosion;

  // L'image du perso
  Image imageDroite;
  Image imageGauche;
  Image imageBas;
  Image imageHaut;
  // L'image de l'explosion d'un perso
  Image imagePersoExplo;
  // L'image en cours du perso
  Image imageCourante;

  //removed in race condition patch [L.E]
  // Les bombes non pos�es du perso
  //FileBombe bombe;
  // Les bombes d�j� pos�es du perso
  FileBombe bombePosees;

  // Lien vers le niveau en cours
  Niveau niveau;
  // Les propri�t�s du joueur
  ProprietesJoueur propj;

  // La case du joueur (ligne, colonne)
  Point coord;
  Point ancienneCoord;
  Point position;
  // Dit si le d�placement est li� au personnage local
  boolean mvtOriginal;

  // Direction o� pousser de la bombe
  int dir;

  // L'arr�t du lancement de bombe
  boolean suite;

  /**
   * Class Constructor
   * Cr�e un personnage avec toutes ses propri�t�s
   * @param c La couleur du joueur
   * @param niveau Le premier niveau de jeu
   * @param numero Le num�ro du joueur
   */

  public Perso(Color c, Niveau niveau, int numero) {
    super("", 0);
    this.niveau = niveau;
    this.numero = numero;

    mvtOriginal = false;

    //removed in race condition patch [L.E]
    //bombe = new FileBombe();
    bombePosees = new FileBombe();
    //removed in race condition patch [L.E]
    //bombe.ajouteBombe(new Bombe(puissance));

    // Positionne le joueur suivant son numero dans un des angles
    switch (numero) {
      case 0:
        coord = new Point(1, 1);
        ancienneCoord = new Point(1, 1);
        break;
      case 1:
        coord = new Point(NBLIGNES - 2, NBCOLONNES - 2);
        ancienneCoord = new Point(NBLIGNES - 2, NBCOLONNES - 2);
        break;
    }

    position = positionStatique();

    propj = new ProprietesJoueur(c);
    propj.setKeys();

    initImages();
  }

  /**
   * Initialise un pointeur sur la zone de jeu
   */

  public static void init(ZoneJeu zj) {
    zoneJeu = zj;
  }

  /**
   * Initialise un pointeur sur le plateau
   */

  public static void initPlateau(Plateau p) {
    plateau = p;
  }

  /**
   * Charge un nouveau niveau en fin de partie
   * @param niveau niveau
   */

  public void chargeNiveau(Niveau niveau) {
    this.niveau = niveau;
  }

  /**
   * R�initialise le joueur en fin de partie
   */

  public void reInitialisation() {
    switch (numero) {
      case 0:
        coord.x = 1;
        coord.y = 1;
        ancienneCoord.x = 1;
        ancienneCoord.y = 1;
        break;
      case 1:
        coord.x = NBLIGNES - 2;
        coord.y = NBCOLONNES - 2;
        ancienneCoord.x = NBLIGNES - 2;
        ancienneCoord.y = NBCOLONNES - 2;
        break;
    }
    mvtOriginal = false;
    deplacePerso(new Point(0, 0), coord);
    reinitJoueur();
    setImage(imageDroite);

    // Retire toutes les bombes posees et remet une bombe libre
    while (bombePosees.retireBombe(0) != null) {
      ;
    }
    //removed in race condition patch [L.E]
    //bombe.ajouteBombe(new Bombe(puissance));
  }

  /**
   * Charge les images du perso suivant sa couleur
   */

  void initImages() {
    ColorChangeImage cci = new ColorChangeImage(Color.white, propj.couleur);

    fichierExplosion = "perso/pexplo.gif";

    // Initialise les images avec le filtre de couleur du joueur
    imagePersoExplo = zoneJeu.load(fichierExplosion, cci);
    imageDroite = zoneJeu.load("perso/persodroit.gif", cci);
    imageGauche = zoneJeu.load("perso/persogauche.gif", cci);
    imageHaut = zoneJeu.load("perso/persohaut.gif", cci);
    imageBas = zoneJeu.load("perso/persobas.gif", cci);

    setImage(imageDroite);
  }

  /**
   * Change la position du personnage
   */

  public void changePos() {
    // R�cup�re la touche en cours (-1 si aucune touche press�e)
    int i = coord.x;
    int j = coord.y;
    int k = propj.key;
    mvtOriginal = true;

    // Fait d�placer le joueur
    if (k == propj.up) {
      i = coord.x - 1;
      j = coord.y;
    }
    if (k == propj.down) {
      i = coord.x + 1;
      j = coord.y;
    }
    if (k == propj.left) {
      i = coord.x;
      j = coord.y - 1;
    }
    if (k == propj.right) {
      i = coord.x;
      j = coord.y + 1;
    }

    valideDeplacement(i, j);
  }

  /**
   * Effectue le d�placement s'il est l�gal
   */

  public void valideDeplacement(int i, int j) {
    // D�place le perso d'une case si la case est libre
    if (testCoord(i, j)) {

      if (mvtOriginal) {
        plateau.envoyer("POSITION", i, j);
        mvtOriginal = false;
      }

      repositionner(i, j);
    }
  }

  /**
   * repositionne et change l'image du perso si la direction a chang�.
   */

  public void repositionner(int i, int j) {

    if (i < coord.x ) {
      setImage(imageHaut);
    }
    else if (i > coord.x ) {
      setImage(imageBas);
    }
    else if (j < coord.y ) {
      setImage(imageGauche);
    }
    else if (j > coord.y ) {
      setImage(imageDroite);
    }

    ancienneCoord = (Point) coord.clone();
    coord.x = i;
    coord.y = j;

    // Prend le bonus dans la case s'il y en a un
    if (isBonus(coord.x, coord.y)) {
      ajoutBonus(niveau, niveau.carte[coord.x][coord.y]);
    }

    deplacePerso(ancienneCoord, coord);
  }

  /**
   * Pose une bombe sur le plateau
   * @param i  La ligne o� est pos�e la bombe
   * @param j  La colonne o� est pos�e la bombe
   */

  void poseBombe(int i, int j) {
    Bombe b;

    //removed in race condition patch [L.E]
    //this check has been pulled up to the callers
    // Si plus de bombe libre, retourne
    //if (nbBombe == 0)
    //    return;

    // Si une bombe est deja pos�e, retourne
    if (bombePosee(i, j)) {
      return;
    }

    // Prends une bombe parmi les libres et la met dans les pos�es
    b = new Bombe(puissance); //bombe.retireBombe(nbBombe - 1);
    plateau.perso.bombePosees.ajouteBombe(b);
    nbBombe--;

    // Pose la bombe en (i, j)
    b.pose(i, j, this, niveau);
  }

  /**
   * Fait prendre un bonus a un perso
   * @param n Le niveau de jeu
   * @param block  Le Block qui contient le bonus
   */

  void ajoutBonus(Niveau n, Block block) {
    // Rajoute le bonus au perso
    switch (block.bonus) {
      case BONUSFLAMME:
        if (puissance + 1 < PUISSANCE_MAX) {
          puissance++;
          //removed in race condition patch [L.E.]
          //for (int i = 0; i < nbBombe; i++)
          //     bombe.getBombe(i).setPuissance(puissance);
        }
        break;
      case BONUSBOMBE:
        if (nbBombe < 5) {
          nbBombe++;
          //removed in race condition patch [L.E]
          //bombe.add(new Bombe(puissance));
        }
        vitesse = 2;
        break;
      case MALUSLENTEUR:
        lenteur = true;
        vitesse = 8;
        break;
      case BONUSVITESSE:
        lenteur = false;
        vitesse = 1;
        break;
      default:
        return;
    }
    block.type = 0;
    block.bonus = 0;

    block.setImage(n.image[block.type]);
    block.paint(zoneJeu.gfond);
    niveau.paint(zoneJeu.gbuffer);
    zoneJeu.paint(zoneJeu.gc);
  }

  /**
   * Dit si un perso peut aller a la case de coordonn�es (i, j)
   */

  boolean testCoord(int i, int j) {

    // Si il y a une bombe, empeche le perso d'aller dessus
    for (int k = 0; k < 2; k++) {
      if (plateau.tabPerso[k].bombePosee(i, j)) {
        return false;
      }
    }

    // Retourne vrai si la case est de type sol ou est un bonus
    return ( (niveau.carte[i][j].type == 0) || (niveau.carte[i][j].type > 3));
  }

  /**
   * Dit si une bombe est posee � la case (i, j)
   */

  boolean bombePosee(int i, int j) {
    int k = 0;
    Bombe b;

    // Parcourt toutes les bombes pos�es de tous les persos
    while (k < plateau.perso.bombePosees.getNbBombe()) {
      b = plateau.perso.bombePosees.getBombe(k);
      if ( (b.i == i) && (b.j == j)) {
        return true;
      }
      else {
        k++;
      }
    }
    return false;
  }

  /**
   * Dit s'il y a un bonus � la case (i, j)
   */

  boolean isBonus(int i, int j) {
    return (niveau.carte[i][j].bonus > 3);
  }

  /**
   * Fait exploser la bombe
   */

  void explosion() {
    suite = true;
  }

  /**
   * R�affiche toutes les bombes sur le plateau
   */

  public static void updateBombe() {
    Bombe b;
    Perso p;
    int k = 0;

    // R�affiche toutes les bombes pos�es
    for (int i = 0; i < plateau.tabPerso.length; i++) {
      p = plateau.tabPerso[i];
      while (k < p.bombePosees.getNbBombe()) {
        b = p.bombePosees.getBombe(k);
        if (b.bombe) {
          b.drawImage(b.image, b.j * OFFSET, b.i * OFFSET);
        }
        k++;
      }
    }
  }

  /**
   * Affiche une image
   */

  void drawImage(Image i, int x, int y) {
    zoneJeu.drawImage(i, x, y);
  }

  void drawImage(Image i, Point p) {
    zoneJeu.drawImage(i, p.x, p.y);
  }

  /**
   * Modifie l'image courante du perso
   */

  void setImage(Image image) {
    imageCourante = image;
  }

  /**
   * Affiche l'image du perso
   */

  void drawImage(Image i) {
    zoneJeu.drawImage(imageCourante, position.x, position.y);
  }

  /**
   * R�affiche tous les persos sur le plateau
   */

  public static void updatePerso() {
    Perso p;

    // R�affiche tous les persos vivant
    for (int i = 0; i < 2; i++) {
      p = plateau.tabPerso[i];
      if (p.vivant) {
        p.drawImage(p.imageCourante);
      }
    }
    zoneJeu.paint(zoneJeu.gc);
  }

  /**
   * D�place le personnage en v * 80 msec
   */

  void deplacePerso(Point pDeb, Point pFin) {
    if (!pDeb.equals(pFin)) {
      for (int i = 1; i < 5; i++) {
        zoneJeu.erase();
        updateBombe();
        position = positionDeplacement(pDeb, pFin, i);
        updatePerso();
        try {
          Thread.sleep(vitesse * 20);
        }
        catch (Exception ex) {
          ;
        }
      }
    }
  }

  /**
   * explose le personnage
   */

  public void explosePerso() {
    vivant = false;
    zoneJeu.erase();
    setImage(imagePersoExplo);
    drawImage(imageCourante, coord.y * OFFSET, coord.x * OFFSET);
    zoneJeu.paint(zoneJeu.gc);
    try {
      Thread.sleep(400);
    }
    catch (Exception e) {
      ;
    }
    zoneJeu.erase();
    zoneJeu.paint(zoneJeu.gc);
    plateau.partie.unEstMort = true;
  }

  /**
   * Calcule la position du personnage en d�placement
   */

  Point positionDeplacement(Point pDeb, Point pFin, int pas) {
    Point p = new Point(0, 0);
    int quartOffset = (int) (OFFSET / 4);
    p.x = (4 - pas) * (pDeb.y * quartOffset) + pas * (pFin.y * quartOffset);
    p.y = (4 - pas) * (pDeb.x * quartOffset) + pas * (pFin.x * quartOffset);
    return p;
  }

  Point positionStatique() {
    Point p = new Point(coord.y * OFFSET, coord.x * OFFSET);
    return p;
  }
}
