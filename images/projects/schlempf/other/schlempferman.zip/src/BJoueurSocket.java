
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.io.*;
import java.net.*;

/**
* R�pertoriation d'une connexion client du c�t� serveur
*/

public class BJoueurSocket implements Runnable {
    // Lien vers le port
    BServeurPort port;      
    
    // Socket de connection au port
    Socket socket = null;
    
    // Flux de donn�es en entr�e
    DataInputStream in;
    // Flux de donn�es en sortie
    DataOutputStream out;
    
    Thread t;
    
    String nom = null;
    String clientParole;
    
    /**
    * Class Constructor
    * Cr�e une connexion entre le port et le client
    * @param s Le socket de connection au port
    * @param prt Lien vers le port
    */
    
    public BJoueurSocket(Socket s, BServeurPort prt) {
        try {
            socket = s; 
            in = new DataInputStream (socket.getInputStream());
            out = new DataOutputStream (socket.getOutputStream());

            port = prt;
            
            if (socket != null) {
                nom = in.readUTF();
            } 
        }    
        catch (Exception ex) { 
            socket = null;
            port.deconnecterClient(nom);
        }
    }

    /**
    * Le thread d'ecoute du client
    */
    
    public void run() {
        try {
            if (socket != null) clientParole = in.readUTF();
            
            // Ecoute du client
            while (socket != null) {
                if (clientParole.compareTo("shutdown") == 0) {
                    // Un client a demand� l'arr�t de la session
                    socket = null;
                    port.deconnecterClient(nom);
                    break;
                }
                else {
                    // Le message est transmis � l'autre client
                    for (int i = 0; i < 2; i++) {
                        if (port.tabBJS[i] != this)
                        port.tabBJS[i].out.writeUTF(clientParole);
                    }
                } 
                
                if (socket != null) clientParole = in.readUTF();
            }
        }
        catch (Exception ex2) { 
            socket = null;
            port.deconnecterClient(nom);
        }
    }
    
    /**
    * Lance le thread
    */

    void ecoute() {
        t = new Thread(this);
        t.start();
    }

    /**
    * Donne le nom du joueur
    */

    String getNom() {
        return nom;
    }

    /**
    * Donne l'adresse du Serveur
    */
    
    InetAddress getAdd_Serveur() {
        return(socket.getInetAddress());
    }

    /**
    * Avertit le joueur que la partie peut �tre lanc�e
    */
    
    void avertir() throws Exception {
        if (socket != null) out.writeUTF("initOK");
    }    

    /**
    * Ferme la socket
    */
    
    void couper() throws Exception {                   
        if (socket != null) {
            out.writeUTF("shutdown");
            socket.close();
            socket = null;
        }
    }
    
    /**
    * Interrompt la partie si un des joueurs la quitte
    * @param nom Le nom du joueur qui a quitte la partie
    */
    
    void interromprePartie(String nom) throws Exception {
        if (socket != null) {
            out.writeUTF("stop" + nom);
            socket.close();
            socket = null;
        }
    }
    
    /**
    * Envoie au joueur son numero pour la partie
    * @param i Le numero du joueur
    */
    
    void envoieNum(int i) throws Exception {
        out.writeUTF("NUM" + String.valueOf(i));
    }

    /**
    * Dit si le joueur est encore connect�
    */
    
    boolean estConnecte() {
        return socket != null;
    }
}
