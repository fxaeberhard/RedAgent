
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.util.Vector;

/**
* File de Bombe
*/

public class FileBombe extends Vector {

    /**
    * Class Constructor
    * Cr�e une file de type First In First Out
    */

	public FileBombe() {
    	super();
    }
    
    /**
    * Ajoute une bombe en fin de File
    */

    void ajouteBombe(Bombe b) {
        try {
            add(b);
        }
        catch(Exception e) {
            return;
        }
    }
    
    /**
    * Retire la bombe d'indice i de la File, null sinon
    */

    Bombe retireBombe(int i) {       
    	if ((i < 0) || (i > elementCount) || isEmpty()) return null; 
    	try {
        	return (Bombe)remove(i);
        }
        catch(Exception e) {
            return null;
        }                    
    }
    
    /**
    * Retourne la bombe d'indice i dans la File, null sinon
    */

    Bombe getBombe(int i) {
    	if ((i < 0) || (i > elementCount) || isEmpty()) return null;
    	try {
        	return (Bombe)elementAt(i);
        }
        catch(Exception e) {
            return null;
        } 
    }
    
    /**
    / Donne le nombre de bombes de la file
    */

    public int getNbBombe() { 
    	return elementCount; 
    }
}
