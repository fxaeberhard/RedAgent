
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

/**
*Affiche un message
*/


public class BoiteDialogue extends JFrame implements ActionListener {
    Container contentPane;
    Label l;
    Button b;

    /**
    * Class Constructor
    */

    BoiteDialogue(String msg) {
        this("Schlempferman Java 2004", msg);
    }

    /**
    * Class Constructor
    */

    BoiteDialogue(String title, String msg) {
        super(title);
        contentPane = getContentPane();
        contentPane.setLayout(new BorderLayout());

        contentPane.add(l = new Label(msg), BorderLayout.NORTH);
        contentPane.add(b = new Button(" OK "), BorderLayout.SOUTH);

        b.addActionListener(this);

        setBounds(calculBounds());
        setResizable(false);
        setVisible(true);

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                removeAll();
                dispose();
            }
        });
    }

    /**
    * G�re les clics sur les boutons
    */

    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == b) {
            removeAll();
            dispose();
        }
    }

    /**
    * Cherche les dimensions de l'�cran, et centre la fen�tre
    */

    Rectangle calculBounds() {
        Dimension d = Toolkit.getDefaultToolkit().getScreenSize();
        int le = d.width;
        int he = d.height;
        int l = 300;
        int h = 120;
        int xPos = (le - l) / 2;
        int yPos = (he - h) / 2;

        return new Rectangle(xPos, yPos, l, h);
    }
}
