
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.net.*;
import java.io.*;
import java.awt.*;
import java.awt.event.*;

/**
* Le serveur � un port. Il permet � 2 clients de se connecter
*/

public class BServeurPort implements Runnable {

    // IHM pour le contr�le du serveur
    BConfigServeur bcs;

    ServerSocket s = null;
    
    // Tableau des connections client
    BJoueurSocket tabBJS[];
    
    //Objets sur lesquels on synchronise
    Object synchro1 = new Object();
    Object synchro2 = new Object();
       
    // Nombre de clients connect�s
    int connection;
    
    Thread t;
    int port;
    boolean partieLancee = false;
    boolean toutNeuf = false;
    
    /**
    * Class Constructor
    */
    
    BServeurPort(BConfigServeur cfg, int prt) {
        bcs = cfg;
        port = prt;
    }

    /**
    * Initialisation de la partie
    */
    
    public void initialiser() {
        toutNeuf = true;
        connection = 0;
        new Thread(this).start();
    }

    /**
    * Commande de r�initialisation
    */
    
    void reinitialiser() {
        try {
            if (s != null) s.close();
            tabBJS = null;
        }
        catch(Exception ex) {
            System.out.println(ex);
        }
        
        initialiser();
    }

    /**
    * Thread du port
    */
    
    public void run() {
        bcs.activerLance(false); 
                
        tabBJS = new BJoueurSocket[2];
        connection = 0;

        try {
            synchronized(synchro1) {
                s = new ServerSocket(port);
                bcs.ecrire("Port " + port + " initialis�... Attente des clients\n");
            }
            
            // Tant qu'il manque des joueurs on accepte les connections
            while (connection < 2) {
                BJoueurSocket temp = new BJoueurSocket(s.accept(), this);
                toutNeuf = false;
                
                synchronized(synchro2) {
                    // Chercher une place libre dans le tableau de clients
                    int i = 0;
                    while(tabBJS[i] != null) i++;
                    tabBJS[i] = temp; 
                    
                    tabBJS[i].ecoute();
                    tabBJS[connection].envoieNum(connection);
                    bcs.ecrire(tabBJS[i].getNom() + " se connecte au port " + port + "\n");
                    connection++;
                }
            }
            
            // Ne plus accepter de connection
            s.close();
            partieLancee = true;
            
            for (int j = 0; j < 2; j++) 
                if(tabBJS[j] != null)
                    tabBJS[j].avertir();
        }
        catch (IOException initImpossible) {
            // if(toutNeuf) bcs.ecrire("Impossible d'initialiser le port " + port + "\n");
        }
        catch (Exception autreProblemeServeur) { 
            bcs.ecrire("Un probl�me du port " + port + " a provoqu� l'arr�t de la session\n");
            bcs.ecrire("Vous devez relancer un nouveau serveur\n");
            
            try {
                if (s != null) {
                    s.close();
                    s = null;
                }
                
                for (int j = 0; j < 2; j++) 
                    if(tabBJS[j] != null)
                        tabBJS[j].couper();
                    }
            catch(Exception ex2) {;}
        }
    }    

    /**
    * Annulation de la partie et mort du port
    */
    
    void couper() {
        synchronized(synchro1) {
            try {
                for (int j = 0; j < 2; j++) 
                    if(tabBJS[j] != null)
                        tabBJS[j].couper();
                if (s != null) {
                    s.close();
                    s = null;
                }
            }
            catch(Exception ex) {;}
        
            System.exit(1);
        }
    }

    /**
    * Ajoute une ligne a la TextArea
    */
    
    void ecrire(String mess) {
        bcs.ecrire(mess);
    }
    
    /**
    * Deconnexion client caus�e par le client
    */
    
    void deconnecterClient(String nom) {
        synchronized(synchro2) {
            int i = 0;
            
            // Nettoyage du tableau de clients
            while(i < 2) {
                if(tabBJS[i] != null && !tabBJS[i].estConnecte()) {
                    tabBJS[i] = null;
                    ecrire(nom + " s'est d�connect� du port " + port + "\n");
                    connection--;
                }           
                i++;
            }
            
            // Si la partie etait en cours on ferme le port
            if (partieLancee) {
                partieLancee = false;
                try {
                    for (int j = 0; j < 2; j++) 
                        if(tabBJS[j] != null)
                            tabBJS[j].interromprePartie(nom);
                    
                    if (s != null) s.close();
                }
                catch (Exception ex) {
                    System.out.println(ex);
                }
            }
        }
        
        reinitialiser();
    }
}
