#! /bin/sh
chdir src/
javadoc -d ../classes/javadoc/ -classpath ./jh.jar *.java