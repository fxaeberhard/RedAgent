
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import java.io.File;
import javax.swing.*;
import javax.swing.filechooser.*;

/**
* Cr�e un filtre de type "*.lvl"
* Permet de n'afficher que les fichiers de type "*.lvl" lorsque l'on ouvre
* ou enregistre un fichier
*/

public class LevelFilter extends FileFilter {       
    // Retourne true si le fichier est de type "*.lvl"

    public boolean accept(File f) {
        if (f.isDirectory())
        return true;
            
        String extension = getExtension(f);
        
        // Regarde si l'extension est "lvl"
        if (extension != null) {
            if (extension.equals("lvl")) 
                return true;
            else 
                return false;
        }
        return false;
    }
    
    /**
    * Retourne l'extension d'un fichier
    */

    public static String getExtension(File f) {
        String ext = null;
        String s = f.getName();
        int i = s.lastIndexOf('.');

        // R�cup�re l'extension
        if (i > 0 &&  i < s.length() - 1) 
                ext = s.substring(i+1).toLowerCase();
    
        return ext;
    }
    
    /**
    * Retourne la description du type de fichier
    */

    public String getDescription() {
        return "Fichiers Level (*.lvl)";
    }
}
