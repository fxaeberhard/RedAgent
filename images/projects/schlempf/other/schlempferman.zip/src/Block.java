
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import javax.swing.*;
import java.awt.*;
import java.awt.image.*;

/**
* Repr�sente une case du niveau, avec:
* son type
* son bonus
* son image
* sa position
*/

public class Block implements Sol, Constantes {
    // La zone de jeu o� afficher les Blocks
    public static ZoneJeu zoneJeu;
    // Le type du Block
    // - Vaut le type du Block si aucun bonus
    // - Vaut 1 si il y a un bonus
    int type;
    // Le bonus du block
    // - Vaut 0 si aucun bonus
    int bonus;
    // L'image du Block, d�pend du type
    Image image;
    //  La position du Block dans le Niveau
    Point position;
    
    /**
    * Class Constructor
    * @param image L'image du Block
    * @param type Le type du block
    * @param i La ligne du Block dans le niveau
    * @param j La colonne du Block dans le niveau
    */
       
    public Block(Image image, int type, int i, int j) {
        this.image = image;
        position = new Point(i * OFFSET, j * OFFSET);
        
        // Suivant le type, on g�re un bonus ou non
        if (type > 3) {
            this.bonus = type;
            this.type = 1;
        }
        else {
            this.bonus = 0;
            this.type = type;
        }
    }
    
    /**
    * Initialise la zone de jeu
    */
       
    public static void init(ZoneJeu zj) {
        zoneJeu = zj;
    }
    
    /**
    * Fait exploser un Block
    * @param image Tableau des images
    * Retourne true si un Block a �t� d�truit, false sinon
    */
       
    public boolean explose(Image image[]) {
        // Suivant le type du Block, on change la valeur de type
        switch(type) {
            case SOL:
                return false;
            case MOU:
                type--;
                setImage(image[type]);
                break;
            case MUR:
                type--;
                setImage(image[type]);
                break; 
            case INDESTRUCTIBLE:
                return true;
            case BONUSFLAMME:
                type=0;
                bonus=0;
                break;
            case BONUSBOMBE:
                type=0;
                bonus=0;
                break;
            case MALUSLENTEUR:
                type=0;
                bonus=0;
                break;
            case BONUSVITESSE:
                type=0;
                bonus=0;
                break;
        }
        
        // Si destruction d'un bonus, on remplace par le sol
        if (bonus > 3) {
            type = bonus;
            setImage(image[bonus]);
        }
        else
            setImage(image[type]);
        paint(zoneJeu.gfond);
        return true;
    }
    
    /**
    * Change l'image du Block
    * @param image La nouvelle image du Block
    */
       
    void setImage(Image image) {
        this.image = image;
    }
    
    /**
    * Repaint le Block dans le fond de la zone de jeu
    * @param g Contexte graphique du fond de la zone de jeu
    */
       
    public void paint(Graphics g) {
        g.drawImage(image, position.x, position.y, zoneJeu);
    }
}
