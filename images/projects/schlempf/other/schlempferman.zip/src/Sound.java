/**
 * <p>Titre : Schlempferman Java 2004 </p>
 * <p>Description : Java Game </p>
 * <p>Copyright : 2004 </p>
 * <p>Soci�t� : EPFL SIN </p>
 * @author Fran�ois-Xavier Aeberhard & Mikael Pelle
 * @version 1.0
 */


import javax.sound.sampled.*;
import java.io.*;
import java.applet.*;
import java.net.*;

public class Sound extends Thread {
  String url;
  AudioClip clip;

  Sound(String url){
    this.url = url;
    start();
  }
  public void run() {
    try{
      AudioClip clip = Applet.newAudioClip(new File(url).toURL());
      clip.play();
      clip.loop();
    }
    catch (MalformedURLException e){}
  }
}
