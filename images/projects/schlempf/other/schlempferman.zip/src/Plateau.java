
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
* G�re une partie, les personnage, le niveau, les scores, etc...
*/

public class Plateau extends JFrame implements KeyListener, Runnable, Constantes {
    // Le conteneur des objets graphiques de la fen�tre
    Container contentPane;
    // Tous les persos de la partie
    BClient client;
    // G�re le graphisme du jeu, et l'affichage des images
    ZoneJeu zoneJeu;
    // G�re le plateau de jeu au niveau type de sols
    Niveau niveau;
    // Utilis� si le personnage est contr�l� par l'ordinateur
    Intelligence intelligence;
    // Tous les persos de la partie
    Perso tabPerso[];
    // Le perso que l'on joue
    Perso perso;
    // Le num�ro du joueur
    int numero;
    // Type du joueur : 1 = humain, 2 = ordinateur
    int typeJoueur;
    // Affiche les scores
    Partie partie;
    // Une boite de dialogue
    BoiteDialogue message;
    // Indique la fin de manche
    boolean finManche;

    /**
    * Class Constructor
    */

    public Plateau(BClient cl) {
        super("Schlempferman Java 2004");
        client = cl;
        numero = client.numero;
        typeJoueur = client.typeClient;

        contentPane = getContentPane();
        zoneJeu = new ZoneJeu();
        contentPane.add(zoneJeu);
        pack();

        // Initialise la zone de jeu
        zoneJeu.init();

        // Cr�e un niveau
        niveau = new Niveau();

        // Cr�e 2 personnages,
        tabPerso = new Perso[2];
        for(int i = 0; i < 2; i++) {
            tabPerso[i] = new Perso(tab[i], niveau, i);
        }

        // perso = le joueur que l'on jouera en local
        perso = tabPerso[numero];
        perso.nom = client.nom;

        partie = new Partie(tabPerso, numero);

        // Initialise le plateau de le niveau
        initPlateau();
        chargeNiveau();

        centrer();
        setVisible(true);
        setResizable(false);

        // Ecoute les actions du clavier si le joueur est humain
        if (typeJoueur == 1) {
            addKeyListener(this);
            zoneJeu.addKeyListener(this);
        }

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e) {
                dispose();
                client.annuler();
            }
        });

        // Active l'intelligence artifielle si le joueur est virtuel
        if (typeJoueur == 2) {
            intelligence = new Intelligence(this, perso, tabPerso[1 - numero], niveau);
        }

        System.gc();
        new Thread(this).start();
    }

    /**
    * Initialise le pointeur de type plateau dans les classes Perso, Bombe, et Partie
    */

    public void initPlateau() {
        Perso.initPlateau(this);
        Bombe.initPlateau(this);
        Partie.initPlateau(this);
    }

    /**
    * Initialise le niveau � la fin d'un manche
    */

    public void chargeNiveau() {
        partie.unEstMort = false;

        if(partie.numNiveau >= 1) {
            niveau.setCarte(partie.numNiveau);

            for(int i = 0; i < 2; i++) {
                tabPerso[i].reInitialisation();
                tabPerso[i].chargeNiveau(niveau);
            }
        }

        // Affiche le buffer a l'�cran avec les personnages et le d�cor
        niveau.paint(zoneJeu.gfond);
        zoneJeu.paint(zoneJeu.gc);
        niveau.paint(zoneJeu.gbuffer);
        zoneJeu.paint(zoneJeu.gc);
        Perso.updatePerso();
        for(int i = 0; i < 2; i++) {
            tabPerso[i].updatePerso();
        }
    }

    /**
    * Le thread principal du jeu, qui g�re la partie
    */

    public void run() {
        while(partie.numNiveau <= partie.nbParties) {
            finManche = false;

            while(!finManche) {
                if (typeJoueur == 2) {
                    new Thread(intelligence).start();
                }

                // Change la position du perso tant que la partie dure
                while(!partie.finPartie()) {
                    if (perso.vivant) perso.changePos();

                    try {
                        Thread.sleep(40);
                    }
                    catch(Exception e) {;}
                }

                try {
                    Thread.sleep(3000);
                }
                catch(Exception e) {;}

                // Donne le gagnant
                for (int i = 0; i < 2; i++)
                     if (tabPerso[i].vivant) {
                        tabPerso[i].nbVictoires++;
                        if(tabPerso[i].nbVictoires == NBCOUPES) {
                            tabPerso[i].gagnant = true;
                            finManche = true;
                            continue;
                        }
                    }

                // Affiche les scores
                partie.afficherVainqueur();
                chargeNiveau();

                if (typeJoueur == 1) {
                    addKeyListener(this);
                    zoneJeu.addKeyListener(this);
                }
            }

            // En fin de manche, donne le gagnant de la manche
            if(perso.estGagnant())
                if (typeJoueur == 1) message = new BoiteDialogue("Bravo, vous avez gagn� cette manche !");
                else System.out.println("L'ordinateur a gagn� cette manche !");
            else
                if (typeJoueur == 1) message = new BoiteDialogue("Quelle tristesse, vous avez perdu cette manche...");
                else System.out.println("L'ordinateur a perdu cette manche !");
            perso.gagnant = false;

            partie.numNiveau++;
            for (int i = 0; i < 2; i++) tabPerso[i].nbVictoires = 0;
            chargeNiveau();
            System.gc();
        }
    }

    /**
    * Gestion des touches: Touche press�e et maintenue
    */

    public void keyPressed(KeyEvent e) {
        // R�cup�re la touche press�e
        int touche = e.getKeyCode();

        // Sauvegarde la touche
        if (touche == perso.propj.up || touche == perso.propj.down |
            touche == perso.propj.left || touche == perso.propj.right) {
            perso.propj.key = touche;
        }

        // Pose les bombes
        if (touche == perso.propj.space) {
            int i = perso.coord.x;
            int j = perso.coord.y;

			//condition pulled up in race condition patch [L.E]
			if (perso.nbBombe > 0) {
           	 	envoyer("POSE", i, j);
            	perso.poseBombe(i, j);
			}
        }
    }

    /**
    * Gestion des touches: Touche press�e
    */

    public void keyTyped(KeyEvent e){;}

    // Gestion des touches: Touche relach�e

    public void keyReleased(KeyEvent e) {
        int touche = e.getKeyCode();

        if(touche == perso.propj.key)
            perso.propj.key = 0;

        if(touche == perso.propj.space)
            perso.pose = false;
    }

    /**
    * Envoie une action vers le serveur
    * @param s action pour le serveur
    */

    void envoyer(String s) {
        try {
            // Envoie la chaine s avec le num�ro du joueur
            client.out.writeUTF(s + String.valueOf(client.numero));
            client.out.flush();
        }
        catch(Exception ex) {System.out.println(ex);}
    }

    /**
    * Envoie une action avec un num�ro au serveur
    * @param s action pour le serveur
    * @param n num�ro
    */

    void envoyer(String s, int n) {
        try {
            // Envoie la chaine s avec l'entier n de l'action,
            // et le num�ro du joueur
            client.out.writeUTF(s + String.valueOf(client.numero)
                + "-" + String.valueOf(n)
            );
            client.out.flush();
        }
        catch(Exception ex) {System.out.println(ex);}
    }

    /**
    * Envoie une action avec ses coordonn�es vers le serveur
    * @param s action pour le serveur
    * @param i coord
    * @param j coord
    */

    void envoyer(String s, int i, int j) {
        try {
            // Envoie la chaine s avec les coordonn�es (i, j) de l'action,
            // et le num�ro du joueur
            client.out.writeUTF(s + String.valueOf(client.numero)
                + "-" + String.valueOf(i)
                + "-" + String.valueOf(j)
            );
            client.out.flush();
        }
        catch(Exception ex) {System.out.println(ex);}
    }

    /**
    * Centre la fen�tre dans l'�cran
    */

    void centrer() {
        Dimension tailleEcran = Toolkit.getDefaultToolkit().getScreenSize();
        int largeurEcran = tailleEcran.width;
        int hauteurEcran = tailleEcran.height;
        int largeur = getSize().width;
        int hauteur = getSize().height;
        int xPos = (largeurEcran - largeur) / 2;
        int yPos = (hauteurEcran - hauteur) / 2;
        setLocation(xPos, yPos);
    }
}
