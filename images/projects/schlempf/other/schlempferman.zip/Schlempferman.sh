#! /bin/sh
echo Schlempferman Java 2004
echo -----------------------  
echo
echo Modo solo
echo
chdir src/
javac -d ../classes/ -classpath ./jh.jar *.java
cp -r * ../classes/
chdir ../classes/
rm *.java
java -classpath :jh.jar Launcher