
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 */


import javax.swing.*;
import java.awt.*;
import java.awt.image.*;
import java.lang.*;
import java.util.*;
import java.awt.event.*;

/**
* G�re les bombes
*/

public class Bombe implements Runnable, Constantes {
    // La zone de jeu o� poser les bombes 
    public static ZoneJeu zoneJeu;
    // Le plateau de jeu
    public static Plateau plateau;
    // Le fichier de l'image de la bombe
    public static String nomFichier;
    // L'image de la bombe
    public static Image image;
    // La flamme de la bombe
    Flamme flamme;
    // La puissance de la bombe
    int puissance;
    // La position de la bombe
    int i, j;
    Niveau niveau;
    // Le perso propri�taire de la bombe
    Perso perso;
    // Le mode de la bombe: pour savoir si elle a explos� ou pas
    boolean bombe;
    // Dit a la flamme de s'arreter de progresser
    boolean stop[];

    /**
    * Class Constructor
    * Cr�e une bombe avec une puissance donn�e
    */

    public Bombe(int puissance) {
        super();
        this.puissance = puissance;
        bombe = true;
        nomFichier = "bombe/bombe.gif";

        // Charge les images
        image = zoneJeu.load(nomFichier);

        // Cr�e les flammes de la bombe
        flamme = new Flamme();
        stop = new boolean[4];
        this.puissance = puissance;
    }

    /**
    * Initialise un pointeur sur la zone de jeu
    */
    
    public static void init(ZoneJeu zj) {
        zoneJeu = zj;
    }

    /**
    * Initialise un pointeur sur le plateau
    */
    
    public static void initPlateau(Plateau p) {
        plateau = p;
    }

    /**
    * Pose une bombe sur le plateau
    * @param i La ligne o� est pos�e la bombe
    * @param j La colonne o� est pos�e la bombe
    * @param perso Le personnage propri�taire de la bombe
    * @param niveau Le niveau de jeu
    */
    
    public void pose(int i, int j, Perso perso, Niveau niveau) {
        this.i = i;
        this.j = j;
        
        // Centre la flamme sur la bombe
        flamme.setPosition(i, j);
        this.perso = perso;
        this.niveau = niveau;

        // Lance l'explosion
        new Thread(this).start();
    }

    /**
    * Lance le thread d'explosion de la bombe
    */
     
    public void run() {
        try {Thread.sleep(500);}
        catch(Exception e) {;}

        // Affiche la bombe
        drawBombe();
        // Affiche les flammes
        drawFlamme();
        
        // Fait la mise a jour apr�s l'explosion
        erase();
        Perso.updatePerso();
        Perso.updateBombe();
        zoneJeu.paint(zoneJeu.gc);

		//removed in race condition patch [L.E]
        // Donne une nouvelle Bombe au personnage
        //perso.bombe.ajouteBombe(new Bombe(puissance));
        perso.nbBombe++;
        plateau.perso.bombePosees.retireBombe(0);
    }

    /**
    * Affiche la bombe avant son explosion
    */
    
    void drawBombe() {
        int i, k;
        for(i = 0; i < 4; i++) stop[i] = false;
        Bombe b;

        i = 0;

        // Affiche les images des bombes
        k = 0;
        zoneJeu.erase();

        while (k < perso.bombePosees.getNbBombe()) {       
            b = perso.bombePosees.getBombe(k);
            drawImage(b.image, b.j * OFFSET, b.i * OFFSET);
            k++;
        }

        Perso.updatePerso();
        Perso.updateBombe();
        zoneJeu.paint(zoneJeu.gc);
        try {Thread.sleep(3750);}
        catch(Exception e) {;}

        erase();
    }

    /**
    * Affiche les flammes et d�truit les Blocks � d�truire
    */
    
    void drawFlamme() {
        bombe = false;
        
        // Si la partie est finie, n'explose pas
        if (!plateau.partie.finPartie()) {
            drawImage(flamme.explosionC, flamme.j * OFFSET, flamme.i * OFFSET);
    
            // Calcule la longueur des flammes dans chaque sens, et les affiche
            for(int k = 1; k <= puissance; k++) {
                if (!stop[BAS]) {
                    flamme.explosion[BAS]++;
                    stop[BAS] = niveau.detruire(i + k, j);
                    drawImage(flamme.explosionV, flamme.j * OFFSET, (flamme.i + k) * OFFSET);
                }
    
                if (!stop[GAUCHE]) {
                    flamme.explosion[GAUCHE]++;
                    stop[GAUCHE] = niveau.detruire(i, j - k);
                    drawImage(flamme.explosionH, (flamme.j - k) * OFFSET, flamme.i * OFFSET);
                }
    
                if (!stop[HAUT]) {
                    flamme.explosion[HAUT]++;
                    stop[HAUT] = niveau.detruire(i - k, j);
                    drawImage(flamme.explosionV, flamme.j * OFFSET, (flamme.i - k) * OFFSET);
                }
    
                if (!stop[DROITE]) {
                    flamme.explosion[DROITE]++;
                    stop[DROITE] = niveau.detruire(i, j + k);
                    drawImage(flamme.explosionH, (flamme.j + k) * OFFSET, flamme.i * OFFSET);
                }
            }
    
            Perso.updatePerso();
            zoneJeu.paint(zoneJeu.gc);
    
            if (plateau.tabPerso[0].vivant && plateau.tabPerso[1].vivant) {
                for(int k = 0; k < 2; k++) {
                    if (touchePerso(plateau.tabPerso[k]) && plateau.tabPerso[k].vivant) {
                        if (k == plateau.perso.numero) {
                            plateau.removeKeyListener(plateau);
                            zoneJeu.removeKeyListener(plateau);
                        }
                        explosePerso(plateau.tabPerso[k]);
                    }
                }
            }
        }
        try {Thread.sleep(50);}
        catch(Exception e) {;}
        erase();
    }
    
    /**
    * Dit si une bombe touche un personnage
    */
    
    boolean touchePerso(Perso p) {
        int pi = p.coord.x;
        int pj = p.coord.y;

        for (int k = 0; k <= flamme.explosion[HAUT]; k++)
            if ((pi == i - k) && (pj == j))
                return true;

        for (int k = 0; k <= flamme.explosion[BAS]; k++)
            if ((pi == i + k) && (pj == j) )
                return true;

        for (int k = 0; k <= flamme.explosion[GAUCHE]; k++)
            if ((pi == i) && (pj == j - k))
                return true;

        for (int k = 0; k <= flamme.explosion[DROITE]; k++)
            if ((pi == i) && (pj == j + k))
                return true;

        return false;
    }

    /**
    * Fait exploser un personnage
    */
    
    void explosePerso(Perso perso) {
        plateau.envoyer("MORT", perso.numero);
        perso.explosePerso();
    }

    /**
    * Modifie la puissance de la bombe
    */
    
    void setPuissance(int p) {
        puissance = p;
    }

    /**
    * Modifie la position de la bombe
    */
    
    void setPosition(int i, int j) {
        this.i = i;
        this.j = j;
        flamme.setPosition(i, j);
    }

    /**
    * Affiche une image
    */
    
    void drawImage(Image i, int x, int y) {
        zoneJeu.drawImage(i, x, y);
    }

    /**
    * Affiche l'image de la bombe
    */
    
    void drawImage() {
        zoneJeu.drawImage(image, this.j*OFFSET, this.i*OFFSET);
    }

    /**
    * Efface la zone de jeu
    */
    
    void erase() {
        zoneJeu.erase();
        zoneJeu.drawImage(perso.imageCourante, perso.coord.y * OFFSET, perso.coord.x * OFFSET);
    }
}
