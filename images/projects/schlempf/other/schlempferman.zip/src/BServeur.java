
/**
 * Author:      Fr�d�ric Viela
 * Date:        2004
 * modified by Eyer Leander
 */


import java.util.Dictionary;
import java.util.Hashtable;
import java.util.Random;
import java.awt.event.ActionEvent;

/**
* Le serveur. Il lance les ports de connexion
*/

public class BServeur {
    // IHM pour le contr�le du serveur
    BConfigServeur bcs;

    BServeurPort tabPort[];
    int port, nbPort;
    
    /**
    * Class Constructor
    */
    
    BServeur() {    
        bcs = new BConfigServeur(this);      
    }


    /** Constructor that launches the application directly **/
    BServeur(String port, String portrange) {
	bcs = new BConfigServeur(this, port, portrange);
	
	//forge the "launch" action in BConfigServer
	//fortunately this project does not use a package structure, otherwise we could not access lancer
	ActionEvent launchAction = new ActionEvent(bcs.lancer, 0, "");
	bcs.actionPerformed(launchAction);
    }




    /**
     * main Method. If no Parameters are given, a configuration window is shown.
     * In all other cases the application is launched directly.
     *
     * Format: java BServeur command1=argument1 command2=argument2 etc
     * Commands:
     * startport=xxx 	(def: 100000)
     * portrange=xxx	(def: 10)
     */
    public static void main(String args[])
    {
	if (args.length == 0) {
	    BServeur bserveur = new BServeur();
	} else {
	    //parse command line parameters
	    Dictionary dict = new Hashtable();
	    for (int i = 0; i < args.length; i++) {
		String argument = args [i].trim();
		if ((argument.indexOf('=') == -1) || (argument.endsWith("=")))
		    continue;
		String command = argument.substring(0, argument.indexOf('='));
		String value = argument.substring(argument.indexOf('=') + 1);
		dict.put(command, value);
	    }
	    
	    String startport = loadFromDict(dict, "startport", "100000");
	    String portrange = loadFromDict(dict, "portrange", "10");
	    
	    BServeur bserveur = new BServeur(startport, portrange);
	}
    }
    
    /** Small help method **/
    private static String loadFromDict(Dictionary dict, String key, String def) {
	String value = (String) dict.get(key);
	if (value == null)
	    return def;
	return value;
    }



    /**
    * Annulation des parties et mort du serveur
    */
    
    void annuler() {
        for (int j = 0; j < nbPort; j++) tabPort[j].couper();
        System.exit(1);
    }

    /**
    * Commande d'initialisation
    */
    
    void lance() {
        port = bcs.port();
        nbPort = bcs.nbPort();
                
        bcs.activerLance(false); 
        bcs.ecrire("Ouverture des ports\n");
                
        tabPort = new BServeurPort[nbPort];
        
        for (int j = 0; j < nbPort; j++) {
            tabPort[j] = new BServeurPort(bcs, port + j);
            tabPort[j].initialiser();
        }
    }

    /**
    * Ajoute une ligne a la TextArea
    * @param mess message pour la TextArea
    */
    
    void ecrire(String mess) {
        bcs.ecrire(mess);
    }
}
